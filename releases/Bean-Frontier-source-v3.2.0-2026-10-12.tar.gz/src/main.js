import {CHARACTER,stanceDimensions} from './dimensions.js';
import {loadVisualAssets} from './weapon-models.js';
import {MAPS} from './maps.js';
import './style.css';
import {THREE,createGraphics} from './gfx.js';
import {createWorld} from './world.js';
import {createInput} from './input.js';
import {createGame} from './game.js';
import {createAimAssist} from './aim-assist.js';
import {createPerformanceMonitor} from './performance.js';
import {seededRandom} from './recoil.js';
import {STEP,clamp} from './physics.js';
import {WEAPONS} from './combat.js';
import * as characterDisplay from './character.js';
import {cancelNavigation,navigationStatus} from './navigation/navigation-loader.js';
import {createLoadingUI} from './loading-ui.js';
import {createMobileRuntime,INPUT_INTERRUPTION_MESSAGES} from './mobile-runtime.js';
import {createOnboarding} from './onboarding.js';
import {readViewport} from './viewport.js';
import {createMinimap} from './minimap.js';
const $=s=>document.querySelector(s),mobile=matchMedia('(pointer:coarse)').matches||navigator.maxTouchPoints>0;
try{await document.fonts.load('900 57px "Noto Sans SC"','豆豆火力岛经典行动工业仓库沙漠城镇救援爆破');await document.fonts.ready;}catch{}
await loadVisualAssets();
const testQuery=new URLSearchParams(location.search),testMode=testQuery.has('test');
// Legacy physics fixtures intentionally request a fully built debug world;
// ?test&lazy exercises the production asynchronous loading path.
const g=createGraphics($('#game'),mobile),world=createWorld(g,'assault',{preview:!testMode||testQuery.has('lazy')}),game=createGame(g,world);
let launchTicket=0,contextLost=false,interruptionTip='',displayTip='',launchInterrupted=false;
const loading={state:'idle',mapId:null,elapsedMs:0,error:null};
const loadingUI=createLoadingUI({onCancel:cancelLaunch,onRetry:()=>launch()});
let helpOpen=false,buyOpen=false,chosenSide='attack',chosenMap='assault',lastPhase='',lastRound=0,uiTime=-Infinity,settings={fps:mobile?30:60,assist:true};
const monitor=createPerformanceMonitor();
const assist=createAimAssist({camera:g.camera,world,actors:game.actors,player:game.player,getViewport:readViewport});
function aimSlowdown(){return assist.value;}
const input=createInput({canvas:$('#game'),onLook:(x,y)=>game.camera.look(x,y),onPause:reason=>{if(loading.state==='loading'){launchInterrupted=true;interruptionTip=INPUT_INTERRUPTION_MESSAGES[reason]??'载入期间操作已中断，请点击继续。';}if(game.state.mode==='playing'){interruptionTip=INPUT_INTERRUPTION_MESSAGES[reason]??'';game.pause();if(interruptionTip)$('#modal-copy').textContent=interruptionTip;}},onAction:id=>{if(onboarding?.visible())return;if(id==='fullscreen'){fullscreen();return;}if(id==='buy'){setBuy(!buyOpen);return;}if(id==='start'){launch();return;}game.action(id);},playing:()=>game.state.mode==='playing'&&!buyOpen&&loading.state!=='loading'&&!contextLost&&!onboarding.visible(),getScope:()=>game.camera.state.scope?'sniper':game.camera.state.aim?'ads':'look',aimSlowdown});game.bindInput(input);
const mobileRuntime=createMobileRuntime({input,audio:game.audio,onTip:message=>{displayTip=message;},onResize:()=>g.resize()});
const onboarding=createOnboarding({isMobile:input.mobile,onShow:()=>input.reset(),onHide:()=>input.reset()});
bind('guide-replay',()=>onboarding.show());
function setBuy(open){assist.reset();buyOpen=!!open&&game.state.phase==='buy'&&game.state.mode==='playing';game.state.buyOpen=buyOpen;input.reset();$('#buy-panel')?.classList.toggle('hidden',!buyOpen);if(buyOpen&&document.pointerLockElement)document.exitPointerLock?.();}
function modeUI(){assist.reset();helpOpen=false;$('#help-copy')?.classList.add('hidden');$('#mobile-settings')?.classList.remove('hidden');const s=game.state;$('#lobby').classList.toggle('hidden',s.mode!=='ready');$('#hud').classList.toggle('hidden',s.mode==='ready');const modal=s.mode==='paused'||s.phase==='match_end';$('#modal').classList.toggle('hidden',!modal);if(s.mode!=='playing')setBuy(false);if(s.phase==='match_end'){$('#modal-title').textContent=s.scores[0]>=5?'胜利！经典行动完成':'本场结束 · 下次再战';$('#modal-copy').textContent=`本场比分 ${s.scores[0]} : ${s.scores[1]}。重开保留当前地图；返回大厅可换地图。`;$('#resume').classList.add('hidden');}else{$('#modal-title').textContent='战术暂停';$('#modal-copy').textContent='对局与计时已暂停。调整操作后继续。';$('#resume').classList.remove('hidden');$('#resume').textContent='继续对局 ↗';}}
game.bindMode(modeUI);
function fullscreen(){if(document.fullscreenElement){document.exitFullscreen?.();return;}document.documentElement.requestFullscreen?.().catch(()=>{});}
async function enterMobileFullscreen(){displayTip='';await mobileRuntime.requestDisplay();}
function cancelLaunch(){launchTicket++;cancelNavigation();Object.assign(loading,{state:'idle',mapId:null,error:null});launchInterrupted=false;loadingUI.hide();onboarding.close();input.reset();game.reset();world.loadMap(world.id,{preview:true});game.reset();mobileRuntime.unlockDisplay();lastPhase='';lastRound=0;updateUI(true);}
async function launch(fresh=false){
 if(loading.state==='loading'||contextLost)return;
 const ticket=++launchTicket,began=performance.now();perfWindow=frames=qualityTimer=0;monitor.reset();game.audio.unlock();
 const id=fresh?world.id:(chosenMap==='random'?MAPS[Math.floor(Math.random()*MAPS.length)].id:chosenMap);
 if(fresh||!['ready','match_end'].includes(game.state.mode))game.reset();
 input.reset();assist.reset();launchInterrupted=false;Object.assign(loading,{state:'loading',mapId:id,error:null});loadingUI.show(MAPS.find(m=>m.id===id)?.name??'准备行动');
 try{
  await enterMobileFullscreen();if(ticket!==launchTicket)return;
  if(!world.loaded||world.id!==id){await world.prepareMap(id);if(ticket!==launchTicket)return;loadingUI.stage('建立场景与战术路线');game.setMap(id);}
  if(ticket!==launchTicket)return;
  loadingUI.hide();await onboarding.maybeShow();if(ticket!==launchTicket)return;
  input.reset();game.start(chosenSide,false);if(launchInterrupted||contextLost||document.hidden){game.pause();$('#modal-copy').textContent=interruptionTip||'载入期间操作已中断，请点击继续。';}else{interruptionTip='';if(displayTip)game.notify(displayTip);}Object.assign(loading,{state:'ready',elapsedMs:Math.round((performance.now()-began)*100)/100});loadingUI.hide();lastPhase='';lastRound=0;updateUI(true);if(game.state.mode==='paused')$('#modal-copy').textContent=interruptionTip||'载入期间操作已中断，请点击继续。';
 }catch(error){if(ticket!==launchTicket||error.name==='AbortError')return;Object.assign(loading,{state:'error',error:error.message});input.reset();loadingUI.error(error.message);}
}
function lobbyChoice(){const chosen=MAPS.find(m=>m.id===chosenMap),rescue=chosen?.mode!=='bomb';const labels=chosenMap==='random'?[['任务方','救援或进攻，由地图决定'],['守方','防守，由地图决定']]:rescue?[['反恐方 CT','突入仓库 · 护送人质'],['守卫方 T','保护仓库 · 阻止救援']]:[['进攻方 T','携带 C4 · 突破包点'],['反恐方 CT','保护包点 · 回防拆包']];for(const [i,id] of ['side-attack','side-defend'].entries()){const el=$('#'+id);el.replaceChildren(document.createTextNode(labels[i][0]));const span=document.createElement('span');span.textContent=labels[i][1];el.appendChild(span);el.classList.toggle('active',chosenSide===(i?'defend':'attack'));el.setAttribute('aria-pressed',String(chosenSide===(i?'defend':'attack')));}text('selected-map-name',chosenMap==='random'?'开始时随机选择':`${chosen?.name??'Assault'} · ${rescue?'救援':'爆破'}`);}
function bind(id,fn){const e=$('#'+id);if(e)e.onclick=fn;}
for(const b of document.querySelectorAll('[data-map]'))b.onclick=()=>{chosenMap=b.dataset.map;chosenSide='attack';input.reset();for(const card of document.querySelectorAll('[data-map]')){const active=card===b;card.classList.toggle('active',active);card.setAttribute('aria-pressed',String(active));}lobbyChoice();};
bind('start-btn',()=>launch());bind('side-attack',()=>{chosenSide='attack';lobbyChoice();});bind('side-defend',()=>{chosenSide='defend';lobbyChoice();});bind('pause',()=>game.pause());bind('resume',()=>{if(contextLost)return;interruptionTip='';game.audio.recover?.();if(helpOpen){modeUI();return;}game.pause();});bind('help-btn',()=>{helpOpen=true;$('#modal').classList.remove('hidden');$('#modal-title').textContent='经典行动指南';$('#modal-copy').textContent='Assault 护送两名人质，Dust2 安放或拆除 C4。先赢五回合。';$('#help-copy')?.classList.remove('hidden');$('#mobile-settings')?.classList.add('hidden');$('#resume').classList.remove('hidden');$('#resume').textContent='知道了 ↗';});bind('restart',()=>launch(true));bind('home',cancelLaunch);bind('full',fullscreen);bind('buy-open',()=>setBuy(true));bind('buy-close',()=>setBuy(false));bind('recommend',()=>game.buy('recommended'));bind('spectate-next',()=>game.action('spectate-next'));bind('spectate-speed',()=>game.action('speed'));
for(const b of document.querySelectorAll('[data-buy]'))b.onclick=()=>game.buy(b.dataset.buy==='armor'?'armor':Number(b.dataset.buy));
for(const b of document.querySelectorAll('[data-weapon]'))b.onclick=()=>game.action('weapon'+b.dataset.weapon);
bind('tactic-a',()=>game.setTactic('A'));bind('tactic-b',()=>game.setTactic('B'));bind('tactic-c',()=>game.setTactic('C'));
const settingKey='bean-frontier-settings';
function restoreSettings(){try{const saved=JSON.parse(localStorage.getItem(settingKey)||'{}');if(typeof saved.music==='boolean')game.audio.setMusic(saved.music);if(typeof saved.sound==='boolean')game.audio.setEffects(saved.sound);input.setSensitivity({look:saved.lookSensitivity??1,ads:saved.adsSensitivity??.6,sniper:saved.sniperSensitivity??.35});input.setLayout?.({size:saved.buttonSize??1,opacity:saved.buttonOpacity??.72});settings.fps=saved.fps===60?60:saved.fps===30?30:settings.fps;settings.assist=saved.assist!==false;}catch{}}
function saveSettings(){const sens=input.getSensitivity(),layout=input.getLayout?.()||{size:1,opacity:.72};try{localStorage.setItem(settingKey,JSON.stringify({version:2,music:game.audio.musicEnabled,sound:game.audio.effectsEnabled,lookSensitivity:sens.look,adsSensitivity:sens.ads,sniperSensitivity:sens.sniper,buttonSize:layout.size,buttonOpacity:layout.opacity,fps:settings.fps,assist:settings.assist}));}catch{}}
function settingsUI(){const sensitivity=input.getSensitivity(),layout=input.getLayout?.()||{size:1,opacity:.72};for(const [id,value] of [['camera-sensitivity',sensitivity.look],['ads-sensitivity',sensitivity.ads],['sniper-sensitivity',sensitivity.sniper],['button-size',layout.size],['button-opacity',layout.opacity]]){if($( '#'+id))$('#'+id).value=value;if($('#'+id+'-value'))$('#'+id+'-value').textContent=Math.round(value*100)+'%';}if($('#fps-setting'))$('#fps-setting').value=settings.fps;if($('#aim-assist'))$('#aim-assist').checked=settings.assist;$('#music').classList.toggle('off',!game.audio.musicEnabled);$('#sound').classList.toggle('off',!game.audio.effectsEnabled);}
for(const [id,key] of [['camera-sensitivity','look'],['ads-sensitivity','ads'],['sniper-sensitivity','sniper']])$('#'+id)?.addEventListener('input',e=>{input.setSensitivity({[key]:Number(e.target.value)});settingsUI();saveSettings();});
for(const [id,key] of [['button-size','size'],['button-opacity','opacity']])$('#'+id)?.addEventListener('input',e=>{input.setLayout?.({[key]:Number(e.target.value)});settingsUI();saveSettings();});
$('#fps-setting')?.addEventListener('change',e=>{settings.fps=Number(e.target.value)===60?60:30;saveSettings();});$('#aim-assist')?.addEventListener('change',e=>{settings.assist=e.target.checked;saveSettings();});
bind('music',()=>{game.audio.setMusic(!game.audio.musicEnabled);saveSettings();settingsUI();});bind('sound',()=>{game.audio.setEffects(!game.audio.effectsEnabled);saveSettings();settingsUI();});
const text=(id,value)=>{const el=$('#'+id);if(el)el.textContent=value;};
const minimap=createMinimap($('#map'));
function map(){minimap.update(world,game);}
function updateUI(force=false){const s=game.state,p=game.player;if(!force&&performance.now()-uiTime<60)return;uiTime=performance.now();
 if(s.phase!==lastPhase||s.round!==lastRound){modeUI();if(s.phase==='buy'){setBuy(true);}else setBuy(false);lastPhase=s.phase;lastRound=s.round;}
 const rescue=(world.mode??world.metadata?.mode)==='rescue',attack=p.team===s.attackTeam,rescued=(game.state.hostages??[]).filter(h=>h.state==='rescued').length,remaining=Math.max(0,(s.phase==='planted'?s.bomb.explodesAt:s.phaseEndsAt??s.time)-s.time);text('map-name',world.name);text('score',`${s.scores?.[0]??0} : ${s.scores?.[1]??0}`);text('round-label',input.mobile?`R${s.round??1}`:`第 ${s.round??1} 回合 · ${rescue?(attack?'CT 救援':'T 守卫'):(attack?'T 进攻':'CT 防守')}`);text('timer',s.phase==='round_end'?'结算':`${Math.floor(Math.ceil(remaining)/60)}:${(Math.ceil(remaining)%60).toString().padStart(2,'0')}`);$('#timer')?.classList.toggle('danger',s.phase==='planted'||remaining<10);
 const actors=game.actors??[],viewed=p.alive?p:(actors.find(a=>a.id===s.spectateId)||p),friends=actors.filter(a=>a.team===p.team&&a.alive).length,foes=actors.filter(a=>a.team!==p.team&&a.alive).length;text('alive-count',`己方 ${friends} · 对方 ${foes}`);
 let objective=s.phase==='round_end'?((s.roundResult?(s.roundResult.winner===p.team?'本回合胜利':'本回合失利')+' · '+s.roundResult.reason:s.toast??'回合结束')):rescue?(s.phase==='buy'?'准备购买 · 正门 / 后门 / 屋顶':attack?`已救出 ${rescued} / 2 · 带领人质前往救援区`:`阻止救援 · 已撤离 ${rescued} / 2`):s.phase==='buy'?'准备购买 · 选择 A / B 战术':s.phase==='planted'?(attack?'C4 已安放 · 守住包点':'C4 已安放 · 按住互动拆除'):attack?'前往 A / B 包点 · 按住互动安包':`重点防守 ${s.tactic} 点 · 留意另一包点`;
 if(!p.alive&&s.phase!=='round_end')objective='已阵亡 · 观战队友';text('objective',objective);text('map-legend',rescue?'▲ 自己　● 队友　＋ 救援区':'▲ 自己　● 队友　A / B 包点');text('region-name',`${world.areaAt?.(viewed)??''}${['low','crouch'].includes(viewed.stance)?' · 低姿':viewed.ladderId?' · 攀爬':''}`);
 $('#health-fill').style.width=Math.max(0,viewed.hp)+'%';text('health-text',Math.ceil(viewed.hp));text('armor-text',viewed.armor?'护甲':'无护甲');text('money',`$ ${p.money??800}`);
 const equipped=viewed.equipment?.[viewed.slot??0],weapon=WEAPONS[equipped?.id??0];text('ammo-count',equipped?.ammo??0);text('ammo-reserve','/ '+(equipped?.reserve??0));text('reload-state',viewed.reloadUntil>s.time?'换弹中':(viewed===p?'':'观战 · ')+(weapon?.name??'手枪'));
 text('weapon-secondary',WEAPONS[0].name+' · 1');text('weapon-primary',viewed.equipment?.[1]?WEAPONS[viewed.equipment[1].id].name+' · 2':'主武器 · 空');for(const b of document.querySelectorAll('[data-weapon]')){b.classList.toggle('active',viewed.slot===Number(b.dataset.weapon));b.classList.toggle('locked',!viewed.equipment?.[Number(b.dataset.weapon)]);b.disabled=!p.alive;}
 $('#hitmarker').style.opacity=s.hit>0?1:0;$('#hurt').style.opacity=s.hurt>0?Math.min(.65,s.hurt):0;$('#crosshair').style.opacity=p.alive&&!buyOpen&&!game.camera.state.scope&&['active','planted'].includes(s.phase)?1:0;$('#scope-overlay')?.classList.toggle('hidden',!game.camera.state.scope||!p.alive||buyOpen);
 text('toast',s.toast);const duplicateToast=s.toast===objective||objective.endsWith(s.toast)||s.phase==='round_end';$('#toast').classList.toggle('show',!duplicateToast&&s.toastUntil>s.time&&s.mode==='playing');
 const near=game.nearestInteraction?.(),kind=near?.type,interaction=s.interaction,progress=interaction&&interaction.actorId===p.id?interaction.progress??0:0,duration=interaction?.duration??(kind==='defuse'?5:3);text('interact-hint',near?(kind==='plant'?'按住安包 · 3 秒':kind==='defuse'?'按住拆包 · 5 秒':kind==='bomb'?'拾取 C4':near.name??'拾取主武器'):'');$('#hud').classList.toggle('context-action',!!near&&p.alive);const useBtn=$('#interact-button');if(useBtn){useBtn.classList.toggle('available',!!near);useBtn.querySelector('span')&&(useBtn.querySelector('span').textContent=kind==='plant'?'安包':kind==='defuse'?'拆包':kind==='hostage'?(near.name?.includes('停止')?'停留':'带领'):kind==='door'?'开门':'互动');useBtn.style.setProperty('--progress',`${Math.min(1,progress)*360}deg`);}const ring=$('#interaction-progress');if(ring){ring.classList.toggle('hidden',progress<=0);ring.style.setProperty('--progress',`${Math.min(1,progress)*360}deg`);text('interaction-progress',`${Math.ceil(progress*100)}%`);}
 const spec=actors.find(a=>a.id===s.spectateId);$('#spectate-hud')?.classList.toggle('hidden',p.alive||s.mode==='ready');text('spectate-name',spec?`观战 ${spec.name??'豆豆队友'}`:'等待下一回合');text('spectate-speed',`观战速度 ${s.spectateSpeed===4?'4×':'1×'}`);
 $('#touch')?.classList.toggle('hidden',buyOpen||s.mode!=='playing'||!p.alive||!['active','planted'].includes(s.phase));$('#buy-open')?.classList.toggle('hidden',s.phase!=='buy'||buyOpen||s.mode!=='playing');text('buy-status',`准备 ${Math.ceil(remaining)} 秒　资金 $ ${p.money??0}`);for(const b of document.querySelectorAll('[data-buy]')){const id=b.dataset.buy,cost=id==='armor'?600:WEAPONS[Number(id)]?.price??0;const owned=id==='armor'?!!p.armor:p.equipment?.[1]?.id===Number(id);b.disabled=s.phase!=='buy'||p.money<cost||owned;b.classList.toggle('owned',owned);b.setAttribute('data-owned',String(owned));}
 for(const [key,id] of [['A','tactic-a'],['B','tactic-b'],['C','tactic-c']]){const el=$('#'+id);el.classList.toggle('active',s.tactic===key);el.classList.toggle('hidden',key==='C'&&!rescue);el.textContent=rescue?({A:'正门突入',B:'后门包抄',C:'屋顶渗透'})[key]:key+' 包点';}text('recommend',p.equipment?.[1]?'补齐护甲 ↗':'一键推荐装备 ↗');map();
}
let accumulator=0,last=performance.now(),lastRender=0,manualUntil=0,perfWindow=0,frames=0,qualityTimer=0;
function step(seconds){if(loading.state==='loading'||contextLost)return;accumulator+=Math.max(0,seconds);let limit=0;while(accumulator+1e-10>=STEP&&limit++<50000){game.update(STEP);assist.update(STEP,mobile&&settings.assist&&game.player.alive&&game.state.mode==='playing'&&!buyOpen&&['active','planted'].includes(game.state.phase));accumulator-=STEP;}}
function render(){if(contextLost)return;if(game.state.mode==='ready'){for(const actor of [...game.actors,...game.hostages.list])actor.group.visible=false;}game.audio.setPhase?.(game.state.phase);game.audio.setListener?.(g.camera);game.audio.update?.(0);if(game.state.mode==='ready')game.camera.update(0,true);characterDisplay.updateBeanDisplay?.(game.player,g.camera,world,game.state.time,true);for(const actor of game.actors??game.enemies)if(actor!==game.player)characterDisplay.updateBeanDisplay?.(actor,g.camera,world,game.state.time,false);g.updateLabels?.();g.actorBatches?.update();g.renderer.render(g.scene,g.camera);const spread=game.combat.getSpread?.(game.player)??0;$('#crosshair').style.setProperty('--spread',`${Math.min(28,4+spread*450)}px`);updateUI();}
function frame(now){const elapsed=Math.max(0,(now-last)/1000);last=now;if(now>manualUntil){if(!document.hidden)step(Math.min(.25,elapsed));}const interval=1000/settings.fps;if(!contextLost&&!document.hidden&&now-lastRender>=interval-1){lastRender=now;const began=performance.now();render();monitor.record(now,performance.now()-began);if(loading.state!=='loading')frames++;}if(!contextLost&&!document.hidden&&loading.state!=='loading'){perfWindow+=elapsed;qualityTimer+=elapsed;}if(mobile&&qualityTimer>5&&perfWindow>1){const actual=frames/perfWindow;if(actual<settings.fps*.78)g.setQuality(g.quality-.08);else if(actual>settings.fps*.94)g.setQuality(Math.min(.85,g.quality+.03));frames=0;perfWindow=0;qualityTimer=0;}requestAnimationFrame(frame);}
function resize(){g.resize();game.camera.update(0,game.player);updateUI(true);render();}window.addEventListener('resize',resize);window.visualViewport?.addEventListener('resize',resize);window.addEventListener('pagehide',()=>{input.reset();if(game.state.mode==='playing')game.pause();game.audio.setPlaying(false);});window.addEventListener('pageshow',()=>{last=performance.now();perfWindow=frames=qualityTimer=0;monitor.reset();});
restoreSettings();settingsUI();lobbyChoice();game.reset();modeUI();updateUI(true);requestAnimationFrame(frame);
window.render_game_to_text=()=>JSON.stringify({...game.snapshot(),selectedMap:chosenMap,loading:{...loading,navigation:navigationStatus(),contextLost},settings:{...settings,...input.getSensitivity(),...input.getLayout?.()},renderQuality:g.quality,performance:{...monitor.snapshot(g.renderer,g.quality,game.audio,g),targetFPS:settings.fps}});
g.onContextState?.(state=>{
 if(state==='lost'){contextLost=true;if(loading.state==='loading')launchInterrupted=true;input.reset();assist.reset();accumulator=0;interruptionTip='画面资源已中断，对局已暂停。恢复后点击继续。';if(game.state.mode==='playing')game.pause();game.audio.setPlaying(false);$('#modal-copy').textContent=interruptionTip;}
 else if(state==='restored'){contextLost=false;last=performance.now();perfWindow=frames=qualityTimer=0;monitor.reset();g.resize();render();if(game.state.mode==='paused')$('#modal-copy').textContent='画面已恢复。点击继续返回对局。';}
});
window.advanceTime=ms=>{manualUntil=performance.now()+300;step(Math.max(0,Number(ms)||0)/1000);render();};
if(new URLSearchParams(location.search).has('test'))window.__gameTest={game,g,world,input,step,render,WEAPONS,characterDisplay,setBuy,settings,assist,monitor,setSeed:value=>game.setRandom(seededRandom(value))};
