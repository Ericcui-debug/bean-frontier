// ============================================================================
// TINY STRIKE — src/weapons/viewmodel.js (module E)
//
// First-person weapon viewmodels: eleven authored weapon GLBs plus one
// canonical skinned arm taken from the CT NPC. Primitive weapons remain only
// as synchronous loading/error fallbacks; rejected procedural hands are not
// used. Persistent wrappers copy the camera transform every frame (no second
// camera / layer tricks), and 'weapon:equip' toggles their visibility.
//
// Public API (per spec):
//   getMuzzleWorldPos(outVec3) -> world position of the current muzzle tip
//                                 (fallback: camera forward 0.4 m)
//   getWeaponGroup()           -> current visible weapon group (or null)
//   update(dt)                 -> copy camera transform, then apply animation
//
// Procedural animations:
//   - idle sway with mouse-look lag + breathing
//   - run/walk bob synced to game.player.moveSpeed2D
//   - fire kick (on 'weapon:fire' byPlayer), pistol slide cycling, AWP bolt
//   - reload drop/tilt/mag-swap choreography timed to the event's duration
//   - equip raise from below, knife slash arcs, grenade wind-up + throw
//   - landing dip ('player:land'), airborne float
//   - model hidden entirely while game.weapons.isScoped()
//
// Scene-graph layout:
//   rig (copies camera pos+quat)  -> added to game.scene
//     pivot (at PIVOT, camera space; all animation offsets applied here so
//            rotations pivot near the grip, not the camera origin)
//       one group per weapon id (posed lower-right, visible one at a time)
//
// No allocations in per-frame code; event handlers only set flags/timers.
// ============================================================================

import * as THREE from 'three';
import {createBeanViewArms} from '../../../adapters/bean-actors.js';
import knifeURL from '../../../../assets-tinystrike/models/viewmodels/knife.glb?url';
import heURL from '../../../../assets-tinystrike/models/viewmodels/hegrenade.glb?url';
import flashURL from '../../../../assets-tinystrike/models/viewmodels/flashbang.glb?url';
import smokeURL from '../../../../assets-tinystrike/models/viewmodels/smokegrenade.glb?url';
const LOCAL_MODELS={knife:knifeURL,hegrenade:heURL,flashbang:flashURL,smokegrenade:smokeURL};
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { clone as cloneSkeleton } from 'three/addons/utils/SkeletonUtils.js';
import { WEAPONS } from './data.js';
import { getCharacterPalette } from '../player/profile.js';
import { weaponInstance, weaponStats } from '../gfx/weapons/registry.js';
import { PROCEDURAL_WEAPON_IDS } from '../gfx/weapons/catalogue.js';

import { shapeMasks } from '../gfx/weapons/build.js';

// ---------------------------------------------------------------------------
// Tuning constants
// ---------------------------------------------------------------------------

// Animation pivot point in camera space — roughly where the firing hand grips.
const PIVOT_X = 0.15;
const PIVOT_Y = -0.145;
const PIVOT_Z = -0.24;

const KICK_RECOVER = 9.5;       // 1/s exponential recovery of fire kick
const KICK_MAX = 1.6;           // clamp on stacked kick impulses
const SWAY_VEL_SMOOTH = 14;     // 1/s smoothing of look velocity
const SWAY_POS_X = 0.0065;      // m per rad/s of yaw velocity
const SWAY_POS_Y = 0.005;
const SWAY_ROT_Y = 0.011;       // rad per rad/s
const SWAY_ROT_X = 0.009;
const SWAY_POS_CLAMP = 0.02;    // m
const SWAY_ROT_CLAMP = 0.055;   // rad
const BOB_STRIDE = 1.9;         // meters per full bob cycle
const BOB_AMP_X = 0.013;
const BOB_AMP_Y = 0.010;
const BOB_AMP_ROLL = 0.022;
const EQUIP_DUR_DEFAULT = 0.28; // visual raise time (event fires at raise start)
const SLASH_DUR = 0.26;
const THROW_DUR = 0.4;          // visual throw follow-through
const THROW_HIDE_AT = 0.11;     // grenade leaves the hand (matches weapons.js)
const BOLT_DUR = 0.85;          // AWP bolt-work choreography
const LAND_RECOVER = 6.5;       // 1/s land-dip recovery
const MUZZLE_FALLBACK_DIST = 0.4;

// Per-weapon pose (camera-space) + fire-kick scale + optional equip time.
const POSES = {
  ak47: { pos: [0.15, -0.270, -0.48], rot: [0.0, 0.04, -0.01], kick: 0.7 },
  m4a1: { pos: [0.15, -0.270, -0.47], rot: [0.0, 0.04, -0.01], kick: 0.6 },
  mp5: { pos: [0.14, -0.250, -0.42], rot: [0.0, 0.04, -0.01], kick: 0.45 },
  awp: { pos: [0.15, -0.270, -0.50], rot: [0.0, 0.035, -0.01], kick: 1.5 },
  deagle: { pos: [0.14, -0.200, -0.37], rot: [0.0, 0.0, 0.0], kick: 1.15 },
  usp: { pos: [0.14, -0.200, -0.36], rot: [0.0, 0.0, 0.0], kick: 0.55 },
  glock: { pos: [0.14, -0.200, -0.35], rot: [0.0, 0.0, 0.0], kick: 0.5 },
  knife: { pos: [0.15, -0.240, -0.35], rot: [-0.02, 0.50, 0.12], kick: 0, equip: 0.2 },
  hegrenade: { pos: [0.13, -0.240, -0.35], rot: [0.18, -0.12, -0.06], kick: 0, equip: 0.24 },
  flashbang: { pos: [0.13, -0.240, -0.35], rot: [0.18, -0.12, -0.06], kick: 0, equip: 0.24 },
  smokegrenade: { pos: [0.13, -0.240, -0.35], rot: [0.18, -0.12, -0.06], kick: 0, equip: 0.24 },
};

// ---------------------------------------------------------------------------
// GLB viewmodels (assets/models/viewmodels/<id>.glb, built in Blender).
// Conventions per asset build: real-world meter scale, origin at the
// right-hand grip point, barrel along -Z, +Y up, identity-rotation Empty
// named "Muzzle" at the barrel tip (top of body for grenades). The files are
// weapon-only; one NPC-derived skinned CT arm is loaded separately, then
// SkeletonUtils-cloned beside each weapon so every viewmodel uses the same
// authored hand proportions, materials, skeleton, and grip pose.
//
// GLB_POSES places each loaded model in camera space. Position/rotation apply
// to the shared wrapper; scale applies only to its weapon-content child so the
// player's hand size cannot vary with asset authoring scale.
// ---------------------------------------------------------------------------
const GLB_PATH = 'assets/models/viewmodels/';
const NPC_ARMS_PATH = GLB_PATH + 'npc-arms-ct.glb';

/**
 * Size of the operative's hand — ONE number, in weapon space, for all eleven.
 *
 * npc-arms-ct.glb is the CT soldier's own right arm, exported at the source
 * file's scale. MEASURED in VM_Grip space: the finger-weighted skin spans
 * 288 x 320 x 330 mm, the Index2R-to-Pinky2R knuckle row spans 173.1 mm and the
 * forearm runs back to z = +596 mm. The character itself is scaled
 * 1.83 / 2.2699 = 0.806 in game (src/ai/bots.js), so the hand a bot carries a
 * weapon with is ~232 mm across — these are stylised soldiers with deliberately
 * oversized hands, which reads fine at third-person distance and reads as a
 * catcher's mitt swallowing the gun when it is 380 mm from the eye. Shot at
 * 0.806: the fist covered the whole receiver and the magazine.
 *
 * 0.33 puts the fist at 95 x 106 x 109 mm, which is a gloved human hand (male
 * 50th-percentile breadth across the metacarpals is 89 mm, ~95 mm gloved), and
 * its grip aperture then matches the 30-35 mm pistol grips these weapons
 * actually have. Below ~0.30 the hand stops reading as a hand and the forearm
 * is too short to reach the corner of the frame; above ~0.42 the fingers are
 * thicker than the grip they are wrapped around.
 *
 * WHAT THIS NUMBER IS MEASURED AGAINST, and the bug that produced two
 * complaints of "the hand is much too big and out of proportion with the gun":
 *
 * the arm and the weapon are children of the SAME wrapper (`_applyProcedural`
 * adds the weapon, `_attachNPCArms` adds the arm), and the geometry inside that
 * wrapper is life size — the procedural AK really is 900 mm long there. The
 * wrapper's own scale is the viewmodel-FOV stand-in (0.80 to 1.0, see
 * PROC_POSES note 4). So the hand-to-gun ratio is set ENTIRELY by the arm's
 * local scale, and the wrapper shrinks hand and gun together.
 *
 * This slot previously stored, per family, this number DIVIDED BY that family's
 * wrapper scale, so that the hand would be the same size in CAMERA space on
 * every weapon. MEASURED consequence, in weapon space where the guns are life
 * size: the same fist was 101 mm across on a pistol, 106 on the MP5, 110 on the
 * rifles and 117 on the AWP — a 25% spread, and 8-30% larger than a human hand
 * on the weapon it was gripping. Constant in camera space is exactly the same
 * statement as "not in proportion to the gun", because the gun is not constant
 * in camera space; and it was worst on the AWP and the MP5, which are the two
 * that were reported. Both extremes have now been shot: 0.806 (the character's
 * own) swallows the receiver, and dividing by the wrapper looms in the lower
 * half of the frame.
 *
 * So every family carries this scale UNDIVIDED. The hand is then in proportion
 * to its weapon by construction on all eleven, and it is the knife and the
 * grenades — the wrapper-scale-1.0 pair that no one ever complained about, and
 * therefore the reference — whose proportion the other nine now inherit.
 *
 * 0.221, NOT the anatomical 0.33. The 0.33 derivation (95 mm gloved
 * metacarpals / 288 mm authored skin) is sound as anatomy and was still
 * rejected on sight by the user after playing with it: "the hands are still
 * way too big, reduce them by 33%". A stylised low-poly hand at true scale
 * reads bigger than a real hand — it has no finger separation, so the
 * silhouette is one solid mitt of the full envelope. 0.33 * 0.67 = 0.221.
 * Every pos below is re-solved at this scale (pos = grip - R*S*FIST_CENTER),
 * and the rifle/smg presentation offset is scaled by the same 0.67 so the
 * smaller fist sits ON the handle instead of inheriting a hiding offset
 * sized for a bigger one.
 */
const NPC_ARM_SCALE = 0.221;

/**
 * Centre of the finger-weighted skin in VM_Grip space, at authoring scale.
 *
 * MEASURED off npc-arms-ct.glb by walking every vertex, summing its skin
 * weights on the Index, Middle, Pinky and Thumb bones and keeping the ones
 * whose finger weight is above 0.5:
 * 232 vertices, bbox centre (45, -7, 12) mm. This is the point that has to land
 * on the weapon's grip; VM_Grip itself does not, because VM_Grip is where the
 * character pack's own AK sat and that is a point ON the skin (measured
 * clearance to the nearest triangle: 0.7 mm), 45 mm off the middle of the fist.
 * Seating VM_Grip at the wrapper origin — which is what identity did — parked
 * the fist up inside the receiver instead of around the grip below it.
 */
export const NPC_ARM_FIST_CENTER = [0.045, -0.007, 0.012];

export const GLB_POSES = {
  ak47: { pos: [0.15, -0.270, -0.48], rot: [0.0, 0.04, -0.01], scale: 1.0 },
  m4a1: { pos: [0.15, -0.270, -0.47], rot: [0.0, 0.04, -0.01], scale: 1.0 },
  mp5: { pos: [0.14, -0.250, -0.42], rot: [0.0, 0.04, -0.01], scale: 1.0 },
  awp: { pos: [0.15, -0.270, -0.50], rot: [0.0, 0.035, -0.01], scale: 0.95 },
  deagle: { pos: [0.14, -0.200, -0.37], rot: [0.0, 0.0, 0.0], scale: 1.1 },
  usp: { pos: [0.14, -0.200, -0.36], rot: [0.0, 0.0, 0.0], scale: 1.1 },
  glock: { pos: [0.14, -0.200, -0.35], rot: [0.0, 0.0, 0.0], scale: 1.1 },
  knife: { pos: [0.15, -0.240, -0.35], rot: [-0.02, 0.50, 0.12], scale: 1.0 },
  hegrenade: { pos: [0.13, -0.240, -0.35], rot: [0.18, -0.12, -0.06], scale: 1.05 },
  flashbang: { pos: [0.13, -0.240, -0.35], rot: [0.18, -0.12, -0.06], scale: 1.05 },
  smokegrenade: { pos: [0.13, -0.240, -0.35], rot: [0.18, -0.12, -0.06], scale: 1.05 },
};

// ---------------------------------------------------------------------------
// Poses for the procedurally modelled firearms (src/gfx/weapons).
//
// These are NOT the GLB poses. The authored GLBs put their origin at the grip
// with the bore only a few millimetres above it; the procedural models are
// dimensionally real, so the origin is the web of the shooting hand and the
// bore sits 75 mm above it on a rifle, 36 mm on a pistol. Reusing the GLB
// numbers therefore dropped the whole weapon a bore-height too low and, at
// 0.48 m from a 74-degree eye, filled a third of the frame with receiver.
//
// Solved from the bore rather than from where the receiver happens to land:
//   1. the bore axis converges on the crosshair — a few degrees left and a
//      touch nose-down, so the muzzle projects up-left of the receiver, on its
//      way to the centre of the screen. That is what reads as "pointing where
//      I am aiming"; a bore parallel to the view direction does not.
//   2. rolled 1-3 degrees so the left flank of the receiver — the side the
//      magwell, the selector and the rollmark are on — turns toward the camera.
//   3. pushed out to 0.29-0.42 m so the whole weapon is inside the frame with
//      the muzzle visible. Anything closer and the barrel leaves the top-left.
// ---------------------------------------------------------------------------
//   4. `scale` is the viewmodel-FOV stand-in. A real 880 mm AK held 375 mm from
//      a 74-degree eye is enormous — correct, and unusable: every shooter draws
//      its viewmodel with a narrower field of view than the world (typically
//      55-65 degrees against 74-90) so the weapon reads at arm's length instead
//      of pressed against the lens. We render the viewmodel in the world scene
//      with the world camera, so the same effect is bought by scaling the whole
//      wrapper — weapon AND hands together, so the grip never drifts.
export const PROC_POSES = {
  m4a1: { pos: [0.126, -0.176, -0.375], rot: [-0.030, 0.062, 0.028], scale: 0.86 },
  ak47: { pos: [0.128, -0.178, -0.385], rot: [-0.030, 0.060, 0.026], scale: 0.84 },
  mp5: { pos: [0.122, -0.170, -0.345], rot: [-0.028, 0.066, 0.030], scale: 0.88 },
  // The bolt gun is 1.2 m long: it sits further out and flatter, or the scope
  // eats the middle of the screen and the muzzle is off the top-left corner.
  awp: { pos: [0.122, -0.172, -0.415], rot: [-0.022, 0.050, 0.020], scale: 0.80 },
  // The pistols sit LOW — the fist and the sleeve leave through the bottom
  // frame edge, and only the knuckle row stays in view under the slide.
  //
  // At the old seat height (-0.144/-0.146, the rifles' solve carried over) the
  // pistol read exactly as the player said: "hand seems to be holding before
  // the weapon … you can see the arm being cut off inside the screen". Both
  // were WRAPPER framing facts, not arm-seat facts — the fist centre measured
  // dead on the family grip mean, but a pistol grip rides 60-100 mm nearer the
  // eye than a rifle grip, so the same correctly-proportioned fist subtended
  // 35% more frame than on the M4 and hung there fully visible, with the
  // sleeve's cut end terminating INSIDE the frame (its dark end-cap facet sat
  // at NDC y = -0.85, 10% of frame height above the bottom edge).
  //
  // MEASURED on the usp from the eye (?arm=1&eye=1, FOV 74, 2560x1440), before
  // and after dropping the wrapper 36 mm, pulling it 15 mm toward the eye and
  // trimming 2 points of scale:
  //   - the arm went from 2.8x the weapon's own pixel area (49.6k skin + 62.3k
  //     sleeve vs 40.4k weapon — the arm WAS the viewmodel) to 0.47x (18.7k +
  //     4.6k vs 49.6k), and the weapon's own coverage ROSE 23% because the eye
  //     now looks down onto the slide's top flat.
  //   - the sleeve's cut ring projects at NDC y = -1.09 (deagle) to -1.15
  //     (glock) at rest and stays below -1.0 with a +12 mm bob-peak lift, so
  //     the sleeve exits through the bottom row (139 px of it on the usp)
  //     instead of ending mid-frame.
  //   - the web of the hand stays under the slide's rear and the muzzle keeps
  //     its exact bearing: rot is untouched, the bore line only translated.
  deagle: { pos: [0.106, -0.182, -0.300], rot: [-0.036, 0.040, 0.016], scale: 0.90 },
  usp: { pos: [0.104, -0.180, -0.295], rot: [-0.034, 0.038, 0.014], scale: 0.90 },
  glock: { pos: [0.104, -0.180, -0.290], rot: [-0.034, 0.040, 0.016], scale: 0.92 },
};

// ---------------------------------------------------------------------------
// First-person arm: the operative's own.
//
// This slot briefly held a procedurally modelled PAIR of arms — jointed
// fingers, gloves, a contact solve against the handguard — on the reasoning
// that the authored arm is only 696 triangles with no fingers and leaves the
// rifles held one-handed. That was the wrong trade and it was rejected on
// sight: a hand modelled from scratch sitting beside the authored soldier
// reads as another game's asset, and two of them wrapped around the gun made
// the mismatch louder. Fidelity of the hand is worth less than belonging to
// the same character the player sees everywhere else in the game.
//
// So all twelve weapons now do what the knife and the grenades always did:
// ONE arm, cloned from npc-arms-ct.glb, tinted from the player profile
// palette so the sleeve and skin match the operative they picked, and posed
// per weapon family by NPC_ARM_POSES.
// ---------------------------------------------------------------------------

// The arm GLB is authored in meters with VM_Grip at its identity origin, and
// `pos` / `rot` / `scale` are family-level tuning controls in wrapper space.
//
// ---------------------------------------------------------------------------
// HOW THESE THREE NUMBERS WERE SOLVED (they are not eyeballed offsets)
//
// 1. rot.x = -(grip rake). Every one of these weapons has a raked pistol grip
//    (addPistolGrip `angle`: 0.28 rad on the Deagle to 0.38 on the M4). The
//    fist's grip channel runs along the arm's own +Y — MEASURED from the bone
//    row, index knuckle at y = +39 mm down to pinky at y = -130 mm with only
//    10 mm of z between them — so tipping the arm back by the rake lays that
//    channel on the grip's axis instead of on the vertical. -0.300 rad is the
//    middle of the family spread and was shot on all seven firearms.
//
// 2. rot.y = +0.524 rad (30 deg). Without it the fingers, which run 180 mm
//    straight down -Z from the wrist before curling 40 mm to -X, closed 18 mm
//    PAST the front strap and the hand read as a fist parked beside the gun:
//    the authored pose is clenched around the character pack's AK, whose grip
//    is 152 mm thick against our 30. Yawing the hand inboard shortens the
//    forward reach to 50 mm, brings the fingertips around onto the far side of
//    the strap where the camera can see them, and swings the forearm out to the
//    lower-right corner where an FPS arm belongs. Shot at 0 / 22 / 35 deg; 30
//    is where the wrap closes without the wrist twisting.
//
// 3. pos = grip - R * S * NPC_ARM_FIST_CENTER, i.e. whatever offset lands the
//    middle of the fist on the grip axis after the rotation and scale above.
//    `grip` is the point 42% of the way down the pistol grip from its top,
//    computed from that weapon's own addPistolGrip(y, z, angle, len) — the
//    fraction is where a hand actually rides a grip, high enough that the web
//    is under the tang and low enough that the pinky is not off the bottom:
//      rifle  ak47 (0, -5.7, 15.0) / m4a1 (0, -2.8, 30.1) -> mean used
//      smg    mp5  (0, -7.6, 21.9)
//      sniper awp  (0, -7.3, 23.5)
//      pistol usp/glock (0, -18.7, 29.5) / deagle (0, -25.1, 31.3) -> mean
//    Two weapons share each firearm family and their grips differ by up to
//    15 mm in z, so the family value is their mean and each is at most 7.5 mm
//    off its own grip — under 1% of frame width at the viewmodel's distance.
//
// 4. scale = NPC_ARM_SCALE on every family, undivided. The derivation and the
//    two ways of getting it wrong are written out on that constant; the short
//    version is that the wrapper is shared with the weapon, so a scale that is
//    constant HERE is a hand that is in proportion to the gun, and a scale that
//    is constant in camera space is not. Changing it means re-solving `pos`.
//
// The knife and the grenades have no pistol grip. Their GLBs are authored with
// the origin AT the grip point, so their target is grip = (12, 18, 0) mm off it
// — the fist centre rides ABOVE the handle line, which is where it sits in a
// hammer grip (the handle beds against the base of the fingers, it is not
// swallowed by the middle of the fist) and which is also what keeps the wrist
// inside the frame: these two wrappers sit at z = -0.35, the closest of the
// eleven, and centred on the origin the bottom 28 mm of the fist and the whole
// sleeve fell out of the bottom of the screen, leaving a floating fist.
// Their rot is +0.244 rad of pitch and +0.384 of yaw for the same reason as the
// firearms — shot against -0.96 and -1.57 rad of pitch, which stood the sleeve
// cone up across the middle of the screen.
//
// The `fallback` offset temporarily seats the same arm against the synchronous
// primitive weapon while the real model builds; it is removed once the real
// model (procedural or GLB) replaces that fallback. The primitive grips were
// modelled 27-39 mm below and up to 51 mm behind the real ones, so these are
// the previously tuned primitive offsets minus the `grip` target above.
// ---------------------------------------------------------------------------
// Every family carries NPC_ARM_SCALE itself — see the note on that constant for
// why it is no longer divided by the wrapper scale. `pos` is re-solved with it:
// pos = grip - R * NPC_ARM_SCALE * NPC_ARM_FIST_CENTER, and because `grip` and
// `rot` are untouched the fist centre lands on the SAME wrapper-space point it
// did before (verified live on all nine visible weapons: 0.000 mm of drift).
//
// The solved seat was NOT abandoned by the presentation fix below — but the
// rifle and SMG families now carry a deliberate (+5, -8, 0) mm offset on top
// of it. That is the player's own verdict, not a solver output: the hand's job
// in first person is to exist peripherally, and after the finger curl was
// relaxed (see NPC_ARM_GRIP) the long guns still showed the sleeve's cut end
// hanging 5 px inside the bottom frame edge on the M4. Half a centimetre right
// and eight millimetres down keeps every finger ON the grip (the fist centre
// stays 5 mm off the bore line and 87/78 mm under the bore — inside the same
// tolerances the solve used) while the sleeve now leaves through the bottom of
// the frame. MEASURED from the eye (?arm=1&eye=1, FOV 74, 2560x1440): the m4a1
// arm mask reaches the frame's bottom row with the offset and stops 5 px short
// without it, and visible skin drops 43.4k px against 45.3k unnudged.
// The sniper and pistol seats stay exactly on the solve: the AWP's wrist is
// occluded by its chassis, and on the pistols the fist under the slide is the
// whole silhouette — nudging the SEAT off the grip reads instantly as a
// floating hand. The pistols' own cut-sleeve report ("you can see the arm
// being cut off inside the screen") was real but it was a wrapper framing
// fact, not a seat fact — fixed by reframing the pistol entries in PROC_POSES
// (see the note there), which move gun and arm together and leave this solve
// alone.
export const NPC_ARM_POSES = {
  rifle: {
    // grip = mean ak47/m4a1 = (0, -4.22, 22.57) mm, plus (+3.35, -5.36, 0) mm of
    // presentation offset (see the note above the table).
    pos: [-0.00661, -0.00731, 0.02467], rot: [-0.300, 0.524, 0], scale: NPC_ARM_SCALE,
    fallback: [0, -0.0387, 0.0284],
  },
  smg: {
    // grip = mp5 (0, -7.6, 21.9) mm, plus the same (+3.35, -5.36, 0) mm offset as
    // the rifles — the MP5 shows the most hand of the nine (its wrapper is the
    // closest long gun) and it hides the same way.
    pos: [-0.00660, -0.01078, 0.02399], rot: [-0.300, 0.524, 0], scale: NPC_ARM_SCALE,
    fallback: [0, -0.0384, -0.0019],
  },
  sniper: {
    // grip = awp (0, -7.3, 23.5) mm. The AWP wrapper is the smallest of the
    // eleven (0.80), so this is the weapon on which the hand now reads smallest
    // in camera space — correct, because its gun is drawn smallest too, and it
    // is the 1.2 m rifle that was reported as being swallowed by the fist.
    pos: [-0.00998, -0.00500, 0.02564], rot: [-0.300, 0.524, 0], scale: NPC_ARM_SCALE,
    fallback: [0, -0.0377, 0.0515],
  },
  pistol: {
    // grip = mean usp/glock/deagle = (0, -20.8, 30.1) mm
    pos: [-0.00996, -0.01854, 0.03216], rot: [-0.300, 0.524, 0], scale: NPC_ARM_SCALE,
    fallback: [0, -0.0272, 0.0079],
  },
  knife: {
    pos: [0.00181, 0.01924, 0.00165], rot: [0.244, 0.384, 0], scale: NPC_ARM_SCALE,
    fallback: [0, 0, 0.050],
  },
  grenade: {
    // The group is pinned to 1 and only the grenade content is scaled 1.05, so
    // the hand is 5% small against the grenade and exactly right against the
    // other ten weapons. That is the trade that matters: the player switches.
    pos: [0.00181, 0.01924, 0.00165], rot: [0.244, 0.384, 0], scale: NPC_ARM_SCALE,
    fallback: [0, 0, 0],
  },
};

export const NPC_ARM_FAMILY = {
  ak47: 'rifle',
  m4a1: 'rifle',
  mp5: 'smg',
  awp: 'sniper',
  deagle: 'pistol',
  usp: 'pistol',
  glock: 'pistol',
  knife: 'knife',
  hegrenade: 'grenade',
  flashbang: 'grenade',
  smokegrenade: 'grenade',
};

// ---------------------------------------------------------------------------
// CLOSING THE HAND.
//
// Three reports of "the hand is inside the gun" were all the same fact, and it
// is not a placement fact: THE AUTHORED HAND IS NOT A FIST. MEASURED off
// npc-arms-ct.glb — knuckle row to fingertip is 73.5 mm in a straight line
// (a human finger is ~75 mm), the fingers are barely curled, and a voxel search
// over the whole hand at 4 mm finds exactly ONE enclosed cell of air. There is
// no bore through it. So no root transform can make it hold a 31 mm pistol
// grip: swept over +/-60 mm of seat, the best any position achieved was 60-70%
// OF THE GRIP'S VOLUME INSIDE THE HAND. The grip went in one side of the fist
// and out the other, which from the eye reads exactly as the complaint — a hand
// with the receiver through it — and no amount of moving it fixed that, which
// is why two rounds of moving it did not.
//
// The hand has finger bones. `_poseNPCArms` now closes them.
//
//   curl  [MCP, PIP, DIP] radians, applied to each of Index/Middle/Pinky about
//         that bone's own local -X. MEASURED which axis that is: a -0.4 rad
//         nudge on Index1R walks the fingertip 18.6 mm toward -x and 22.0 mm
//         toward +z, i.e. straight at the palm, while +X, +/-Y and +/-Z all
//         swing it away from it.
//   thumb [flex, spread, tip] — the thumb lies along the back strap rather than
//         curling with the fingers.
//
// The 1.20 rad voxel-solved fist was measured tight and looked WRONG, and the
// player said so looking at the M4: folded to a full fist the hand reads as a
// pale ball parked at the receiver/stock junction — knuckles proud of the
// receiver line, thumb bump hooked over it, the wrist reading as a cut end —
// "a half cut hand [that] goes into the weapon and does not really hold it".
// The presentation rule that replaced it: the hand exists peripherally, the
// player reads the GUN, and any trade between grip correctness and hand
// visibility is decided toward LESS VISIBLE.
//
// So the LONG GUNS (rifle/smg/sniper) now curl just far enough to stay
// visually connected, and no further. MEASURED from the eye position
// (?arm=1&eye=1, FOV 74, 2560x1440, skin forced to a flat key and counted):
//   - dead straight (the original 74239b6 pose) the hand tears into separate
//     skin patches from the eye — 3 patches on the AWP (11.3k/1.8k/0.9k px),
//     3 on the AK, 2 on the MP5 — the "open palm you can see through".
//   - the gap closes at MCP 0.15 rad on both gap-prone guns and stays closed
//     from there up; [0.35, 0.20, 0.12] is 2.3x that threshold and still takes
//     the fingers 71% of the way back toward straight from 1.20.
//   - visible skin on the M4 falls from 54.7k px (1.20 fist, the screenshot
//     complaint) to 43.4k at 0.35 with the seat offset; every long gun is one
//     connected skin mass and nothing crosses the weapon's top silhouette.
// The thumb follows the same rule: [0.15, 0.05, 0.10] lies flat along the
// strap instead of folding over the top of the grip.
//
// The PISTOLS keep the full solved wrap, deliberately. Opening the pistol
// fist was shot both ways and less curl LOSES on both counts there: the open
// fingers swing around the visible side of the grip (deagle skin 96.1k px
// open vs 90.7k closed — the fist under the slide IS the pistol's whole
// contact patch, there is no receiver to hide behind), and with the light
// thumb the thumb tip shows in the tang notch behind the slide (3 columns,
// 32 px above the top silhouette; the 0.35-flex thumb pulls it back under —
// re-measured to 0 columns). A pistol fist wrapped tight is also simply what
// the pose is in reality; nothing about it read as wrong from the eye.
//
// The knife and the grenades keep an open hand: their handles are 20-30 mm
// across and their poses were never reported. A light curl only.
// ---------------------------------------------------------------------------
export const NPC_ARM_GRIP = {
  rifle: { curl: [0.35, 0.20, 0.12], thumb: [0.15, 0.05, 0.10] },
  smg: { curl: [0.35, 0.20, 0.12], thumb: [0.15, 0.05, 0.10] },
  sniper: { curl: [0.35, 0.20, 0.12], thumb: [0.15, 0.05, 0.10] },
  pistol: { curl: [1.20, 0.50, 0.30], thumb: [0.35, 0.10, 0.30] },
  knife: { curl: [0.55, 0.35, 0.20], thumb: [0.20, 0, 0.15] },
  grenade: { curl: [0.55, 0.35, 0.20], thumb: [0.20, 0, 0.15] },
};

const NPC_FINGER_CHAINS = [
  ['Index1R', 'Index2R', 'Index3R'],
  ['Middle1R', 'Middle2R', 'Middle3R'],
  ['Pinky1R', 'Pinky2R', 'Pinky3R'],
];

/**
 * Close the cloned hand's fingers onto the grip.
 *
 * ABSOLUTE, never cumulative: the rest rotation is cached on the bone the first
 * time it is touched and every call writes `rest - curl`. `_poseNPCArms` runs
 * again whenever a weapon's real model replaces its fallback, and a `-=` there
 * would fold the hand twice into its own wrist the moment the procedural build
 * landed.
 */
export function applyNPCArmGrip(arms, family, override = null) {
  const spec = override || NPC_ARM_GRIP[family];
  if (!arms || !spec) return;
  const bones = new Map();
  arms.traverse((o) => {
    if (o.isBone) bones.set(o.name, o);
  });
  const rest = (bone, axis) => {
    const key = 'npcRest' + axis;
    if (bone.userData[key] === undefined) bone.userData[key] = bone.rotation[axis];
    return bone.userData[key];
  };
  for (const chain of NPC_FINGER_CHAINS) {
    for (let i = 0; i < chain.length; i++) {
      const bone = bones.get(chain[i]);
      if (!bone) continue;
      bone.rotation.x = rest(bone, 'x') - (spec.curl[i] || 0);
    }
  }
  const t1 = bones.get('Thumb1R');
  const t2 = bones.get('Thumb2R');
  if (t1) {
    t1.rotation.x = rest(t1, 'x') - (spec.thumb[0] || 0);
    t1.rotation.z = rest(t1, 'z') + (spec.thumb[1] || 0);
  }
  if (t2) t2.rotation.x = rest(t2, 'x') - (spec.thumb[2] || 0);
  arms.updateMatrixWorld(true);
}

// ---------------------------------------------------------------------------
// Small math helpers (scalar only — no allocations)
// ---------------------------------------------------------------------------
function clamp(v, lo, hi) {
  return v < lo ? lo : v > hi ? hi : v;
}

function smoothstep(a, b, x) {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}

// Gaussian-ish bump centered at c with width w (for reload jolts).
function bump(x, c, w) {
  const d = (x - c) / w;
  return Math.exp(-d * d);
}

function easeOutCubic(t) {
  const u = 1 - clamp(t, 0, 1);
  return 1 - u * u * u;
}

function easeOutQuad(t) {
  const u = clamp(t, 0, 1);
  return u * (2 - u);
}

// Scratch for the hip/bob transform work — module scope, so the per-frame path
// allocates nothing.
const _hb0 = new THREE.Vector3();
const _hb1 = new THREE.Vector3();
const _hb2 = new THREE.Vector3();
const _hbM = new THREE.Matrix4();

/**
 * Wrist orientation from the two directions a grip is actually described by:
 * where the fingers point and which way the back of the hand faces.
 *
 * Hand-local space is -Z along the fingers and +Y out of the back of the hand,
 * so `finger` is negated into +Z and `back` is orthonormalised against it.
 */
function handBasis(out, finger, back) {
  _hb0.set(-finger[0], -finger[1], -finger[2]).normalize(); // hand +Z
  _hb1.set(back[0], back[1], back[2]);
  _hb1.addScaledVector(_hb0, -_hb1.dot(_hb0));
  if (_hb1.lengthSq() < 1e-8) _hb1.set(0, 1, 0).addScaledVector(_hb0, -_hb0.y);
  _hb1.normalize(); // hand +Y
  _hb2.crossVectors(_hb1, _hb0).normalize(); // hand +X
  _hbM.makeBasis(_hb2, _hb1, _hb0);
  return out.setFromRotationMatrix(_hbM);
}

// ============================================================================
// ViewModel
// ============================================================================
export default class ViewModel {
  constructor(game) {
    this.game = game;

    // ---- shared geometries / materials ------------------------------------
    this._initShared();

    // ---- rig --------------------------------------------------------------
    this.rig = new THREE.Group();
    this.rig.name = 'viewmodel-rig';
    this.rig.scale.setScalar(.8);
    this._wallRetraction=0;
    this.rig.frustumCulled = false;
    this.rig.visible = false;

    this.pivot = new THREE.Group();
    this.pivot.name = 'viewmodel-pivot';
    this.pivot.position.set(PIVOT_X, PIVOT_Y, PIVOT_Z);
    this.rig.add(this.pivot);

    // ---- build every weapon model once ------------------------------------
    // Procedural box models are built synchronously as the always-available
    // fallback; GLB viewmodels stream in async and swap each group's content
    // in place when they arrive (the group node itself — which all animation
    // code manipulates — is preserved).
    this._models = {};
    this._npcArmsSource = null;
    this._buildAll();
    // The seven firearms are modelled procedurally at real scale (see
    // src/gfx/weapons): every part is geometry, so the same model serves the
    // viewmodel here and the third-person soldiers in src/ai/bots.js. The
    // knife and the grenades stay on their authored GLBs.
    this.proceduralReady=this._buildProceduralWeapons();
    this.assetReady=this._loadGLBModels();
    this.ready=Promise.all([this.proceduralReady,this.assetReady]);

    if (game.scene && typeof game.scene.add === 'function') {
      game.scene.add(this.rig);
    }

    // ---- animation state --------------------------------------------------
    this._currentId = null;       // adopted lazily from weapons / equip events
    this._t = 0;

    // fire kick
    this._kick = 0;
    this._kickYawV = 0;
    this._kickRollV = 0;

    // look sway
    this._lastYaw = 0;
    this._lastPitch = 0;
    this._haveLook = false;
    this._yawVel = 0;
    this._pitchVel = 0;

    // movement bob
    this._bobPhase = 0;
    this._bobAmp = 0;

    // landing dip / air float
    this._landK = 0;
    this._airY = 0;

    // equip raise
    this._equipT = 1;
    this._equipDur = EQUIP_DUR_DEFAULT;

    // reload choreography (timed to the event's duration)
    this._reload = { active: false, t: 0, dur: 2.5 };

    // knife slash
    this._slash = { active: false, t: 0, side: 1 };

    // grenade wind-up + throw
    this._wind = 0;
    this._throw = { active: false, t: 0 };
    this._payloadHidden = false;

    // AWP bolt cycle
    this._bolt = { active: false, t: 0 };

    // scratch vectors
    this._vDir = new THREE.Vector3();
    this._muzzleOut = new THREE.Vector3();

    // ---- events (handlers only set flags — cheap and re-entrant safe) -----
    const ev = game.events;
    if (ev && typeof ev.on === 'function') {
      ev.on('weapon:equip', (p) => this._onEquip(p));
      ev.on('weapon:fire', (p) => this._onFire(p));
      ev.on('weapon:reload:start', (p) => this._onReloadStart(p));
      ev.on('weapon:reload:end', () => this._onReloadEnd());
      ev.on('grenade:throw', () => this._onThrow());
      ev.on('player:land', (p) => this._onLand(p));
      ev.on('profile:changed', (p) => this.applyProfileAppearance(p?.characterId));
    }
  }

  // ==========================================================================
  // Public API
  // ==========================================================================

  /**
   * Writes the CURRENT world-space muzzle tip into `out` and returns it.
   * Falls back to camera-forward 0.4 m when no weapon model is visible.
   * Safe to call mid-frame (combat fires before our update): the rig is
   * re-synced to the camera before sampling.
   */
  getMuzzleWorldPos(out) {
    if (!out || !out.isVector3) out = this._muzzleOut;
    const g = this.game;
    const cam = g ? g.camera : null;
    const model = this._models ? this._models[this._currentId] : null;

    if (this.rig.visible && model && model.visible && model.userData.muzzle) {
      // Mid-frame callers (combat) need this frame's camera transform even
      // though our update() may not have run yet. Cheap: copy pos + quat.
      if (cam) {
        this.rig.position.copy(cam.position);
        this.rig.quaternion.copy(cam.quaternion);
      }
      model.userData.muzzle.getWorldPosition(out); // updates parent matrices
      // Never hand a non-finite point to combat or effects. Both consume this
      // without checking, and a NaN origin does not throw — it silently
      // deletes the tracer, the muzzle flash, the smoke wisp and the shell,
      // which is a far more expensive failure than a slightly wrong origin.
      // Falling through to the camera ray keeps those four effects alive.
      if (Number.isFinite(out.x) && Number.isFinite(out.y) && Number.isFinite(out.z)) {
        return out;
      }
    }

    if (cam) {
      cam.getWorldDirection(this._vDir);
      out.copy(cam.position).addScaledVector(this._vDir, MUZZLE_FALLBACK_DIST);
    } else {
      out.set(0, 0, 0);
    }
    return out;
  }

  /** The currently visible weapon group, or null when nothing is shown. */
  getWeaponGroup() {
    const model = this._models ? this._models[this._currentId] : null;
    return this.rig.visible && model && model.visible ? model : null;
  }

  /** Recolors the authored NPC sleeve/skin using the selected fixed preset. */
  applyProfileAppearance(characterId = this.game?.profile?.characterId) {
    for (const id in this._models) {
      const arms = this._models[id]?.userData?.npcArms;
      if (arms) this._styleNPCArms(arms, characterId);
    }
  }

  // ==========================================================================
  // Per-frame update — camera copy FIRST, then animation offsets.
  // ==========================================================================
  update(dt) {
    const g = this.game;
    const cam = g.camera;
    if (!cam) return;
    // Keep the original 80% bean viewmodel in landscape; portrait narrows
    // horizontal FOV, so compensate its screen footprint independently.
    this.rig.scale.setScalar(.8*Math.min(1,Math.max(.4,cam.aspect/1.25)));
    this._t += dt;

    const player = g.player || null;      // lazy sibling lookups (rule 9)
    const weapons = g.weapons || null;
    const input = g.input || null;
    const state = g.state || null;

    // Missed-event safety net: adopt weapons' current id if out of sync
    // (covers boot order and any equip we did not observe).
    if (weapons && weapons.currentId && weapons.currentId !== this._currentId) {
      this._beginEquip(weapons.currentId);
    } else if (!this._currentId) {
      this._beginEquip('knife');
    }

    // ---- visibility --------------------------------------------------------
    const phase = state ? state.phase : 'menu';
    const scoped =
      !!(weapons && typeof weapons.isScoped === 'function' && weapons.isScoped());
    const alive = !player || player.alive !== false;
    const show = alive && !scoped && phase !== 'menu' && phase !== 'gameEnd';

    // ---- advance / decay all transient state (even while hidden, so the
    //      model never pops mid-animation when it reappears) -----------------
    const kickDecay = Math.exp(-KICK_RECOVER * dt);
    this._kick *= kickDecay;
    this._kickYawV *= kickDecay;
    this._kickRollV *= kickDecay;
    if (this._kick < 1e-4) this._kick = 0;

    this._landK *= Math.exp(-LAND_RECOVER * dt);
    if (this._landK < 1e-3) this._landK = 0;

    if (this._equipT < this._equipDur) this._equipT += dt;

    const rl = this._reload;
    if (rl.active) {
      rl.t += dt;
      if (rl.t >= rl.dur) rl.active = false;
    }

    const sl = this._slash;
    if (sl.active) {
      sl.t += dt;
      if (sl.t >= SLASH_DUR) sl.active = false;
    }

    const th = this._throw;
    if (th.active) {
      th.t += dt;
      if (th.t >= THROW_DUR) th.active = false;
    }

    const bo = this._bolt;
    if (bo.active) {
      bo.t += dt;
      if (bo.t >= BOLT_DUR) bo.active = false;
    }

    // Grenade wind-up: pin pulled while LMB is held on an equipped grenade.
    const curDef = WEAPONS[this._currentId];
    let windTarget = 0;
    if (
      curDef &&
      curDef.grenade &&
      !th.active &&
      input &&
      input.firing &&
      phase !== 'freeze' &&
      !(state && state.buyOpen)
    ) {
      const ca =
        weapons && typeof weapons.currentAmmo === 'function'
          ? weapons.currentAmmo()
          : null;
      if (ca && ca.mag > 0) windTarget = 1;
    }
    this._wind += (windTarget - this._wind) * (1 - Math.exp(-10 * dt));

    // ---- look-lag sway velocities ------------------------------------------
    const yaw = player ? player.yaw || 0 : 0;
    const pitch = player ? player.pitch || 0 : 0;
    if (!this._haveLook) {
      this._lastYaw = yaw;
      this._lastPitch = pitch;
      this._haveLook = true;
    }
    let dyaw = yaw - this._lastYaw;
    if (dyaw > Math.PI) dyaw -= Math.PI * 2;
    else if (dyaw < -Math.PI) dyaw += Math.PI * 2;
    const dpitch = pitch - this._lastPitch;
    this._lastYaw = yaw;
    this._lastPitch = pitch;
    const invDt = dt > 1e-4 ? 1 / dt : 0;
    const sm = 1 - Math.exp(-SWAY_VEL_SMOOTH * dt);
    this._yawVel += (clamp(dyaw * invDt, -10, 10) - this._yawVel) * sm;
    this._pitchVel += (clamp(dpitch * invDt, -10, 10) - this._pitchVel) * sm;

    // ---- movement bob ------------------------------------------------------
    const speed = player && typeof player.moveSpeed2D === 'number' ? player.moveSpeed2D : 0;
    const onGround = player ? player.onGround !== false : true;
    const cfg = g.config;
    const runSpeed = (cfg && cfg.PLAYER && cfg.PLAYER.RUN_SPEED) || 5.2;
    const speedFrac = clamp(speed / runSpeed, 0, 1);
    const bobTarget = onGround && speed > 0.35 ? speedFrac : 0;
    this._bobAmp += (bobTarget - this._bobAmp) * (1 - Math.exp(-8 * dt));
    this._bobPhase += speed * dt * ((Math.PI * 2) / BOB_STRIDE);

    // Air float: gun drifts opposite vertical velocity while airborne.
    const vy = player && player.velocity ? player.velocity.y || 0 : 0;
    const airTarget = onGround ? 0 : clamp(-vy * 0.0045, -0.018, 0.022);
    this._airY += (airTarget - this._airY) * (1 - Math.exp(-9 * dt));

    // ---- rig follows the camera (BEFORE animation offsets) -----------------
    this.rig.visible = show;
    this.rig.position.copy(cam.position);
    this.rig.quaternion.copy(cam.quaternion);
    if (!show) return; // hidden: skip pose composition + matrix flush

    // ---- compose pivot offsets --------------------------------------------
    let px = PIVOT_X;
    let py = PIVOT_Y;
    let pz = PIVOT_Z;
    let rx = 0;
    let ry = 0;
    let rz = 0;

    // idle breathing (fades out while moving)
    const idle = 1 - this._bobAmp;
    py += Math.sin(this._t * 1.5) * 0.0014 * idle;
    px += Math.sin(this._t * 0.9) * 0.0008 * idle;
    ry += Math.sin(this._t * 0.7) * 0.0022 * idle;

    // look-lag sway
    px += clamp(this._yawVel * SWAY_POS_X, -SWAY_POS_CLAMP, SWAY_POS_CLAMP);
    py += clamp(-this._pitchVel * SWAY_POS_Y, -SWAY_POS_CLAMP, SWAY_POS_CLAMP);
    ry += clamp(-this._yawVel * SWAY_ROT_Y, -SWAY_ROT_CLAMP, SWAY_ROT_CLAMP);
    rx += clamp(-this._pitchVel * SWAY_ROT_X, -SWAY_ROT_CLAMP, SWAY_ROT_CLAMP);

    // run/walk bob
    const ph = this._bobPhase;
    const amp = this._bobAmp;
    px += Math.sin(ph) * BOB_AMP_X * amp;
    py += -Math.abs(Math.sin(ph)) * BOB_AMP_Y * amp;
    rz += Math.sin(ph) * BOB_AMP_ROLL * amp;

    // airborne float + landing dip
    py += this._airY;
    py -= 0.05 * this._landK;
    rx -= 0.1 * this._landK;

    // fire kick — translate back toward the camera, muzzle rises
    const kick = this._kick;
    if (kick > 0) {
      pz += 0.05 * kick;
      py += 0.007 * kick;
      rx += 0.13 * kick;
      ry += this._kickYawV;
      rz += this._kickRollV;
    }

    // equip raise — from below, tilted down, over the raise window
    if (this._equipT < this._equipDur) {
      const raise = 1 - easeOutCubic(this._equipT / this._equipDur);
      py -= 0.24 * raise;
      rx -= 0.85 * raise;
      rz += 0.3 * raise;
    }

    // reload choreography — drop + tilt, mag-out / mag-in jolts, raise at end
    let magOut = 0;
    if (rl.active && rl.dur > 0) {
      const n = clamp(rl.t / rl.dur, 0, 1);
      const drop = smoothstep(0, 0.14, n) * (1 - smoothstep(0.72, 0.95, n));
      const j1 = bump(n, 0.3, 0.05);  // mag released
      const j2 = bump(n, 0.62, 0.05); // fresh mag seated
      py -= 0.045 * drop + 0.012 * j1 - 0.008 * j2;
      px += 0.014 * drop;
      pz += 0.018 * drop;
      rx -= 0.34 * drop + 0.05 * j2;
      rz += 0.16 * drop + 0.04 * j1;
      // busy-hands wobble while low
      rz += Math.sin(n * 43) * 0.016 * drop * bump(n, 0.48, 0.22);
      magOut = smoothstep(0.22, 0.34, n) * (1 - smoothstep(0.5, 0.62, n));
    }

    // knife slash — fast arc across the view, alternating sides
    if (sl.active) {
      const p = sl.t / SLASH_DUR;
      const arc = Math.sin(p * Math.PI);
      ry += sl.side * 0.62 * arc;
      rz += sl.side * 0.45 * arc;
      rx -= 0.3 * arc;
      pz -= 0.09 * arc;
      py += 0.02 * arc;
    }

    // grenade wind-up (cocked back over the shoulder) + throw sweep
    if (this._wind > 0.001) {
      const w = this._wind;
      px += 0.025 * w;
      py += 0.03 * w;
      pz += 0.075 * w;
      rx += 0.5 * w;
    }
    if (th.active) {
      const p = th.t / THROW_DUR;
      const swing = p < 0.3 ? easeOutQuad(p / 0.3) : 1 - smoothstep(0.3, 1, p);
      pz -= 0.13 * swing;
      rx -= 0.55 * swing;
      py += 0.035 * swing;
      // grenade leaves the hand — hide the payload meshes
      if (th.t >= THROW_HIDE_AT && !this._payloadHidden) {
        this._setPayloadVisible(false);
      }
    }

    // AWP bolt work — gun cants right while the bolt is cycled
    let boltPull = 0;
    if (bo.active && this._currentId === 'awp' && bo.t > 0) {
      const n = clamp(bo.t / BOLT_DUR, 0, 1);
      boltPull = bump(n, 0.45, 0.17);
      rz += 0.12 * boltPull;
      rx -= 0.05 * boltPull;
      py -= 0.008 * boltPull;
    }

    // Pull the gun toward the eye before the barrel reaches a wall. The
    // native recoil/reload transforms remain on the same pivot.
    cam.getWorldDirection(this._vDir);
    const closeWall=g.world?.raycast?.(cam.position,this._vDir,1.25);
    const retractTarget=closeWall?Math.max(0,.95-closeWall.distance):0;
    this._wallRetraction+=(retractTarget-this._wallRetraction)*(1-Math.exp(-18*dt));
    pz+=this._wallRetraction*.7;py-=this._wallRetraction*.12;
    this.pivot.position.set(px, py, pz);
    this.pivot.rotation.set(rx, ry, rz);

    // ---- moving parts on the current model --------------------------------
    const model = this._models[this._currentId];
    if (model) {
      const ud = model.userData;
      if (ud.slide) {
        // pistol slide cycles back with the kick
        ud.slide.position.z = ud.slideBaseZ + Math.min(1, kick) * 0.022;
      }
      if (ud.mag) {
        ud.mag.position.y = ud.magBaseY - 0.09 * magOut;
      }
      if (ud.bolt) {
        ud.bolt.position.z = ud.boltBaseZ + 0.032 * boltPull;
      }
      // Trigger finger. The rest pose already has the slack taken up on the
      // trigger face, so this only drives the last 0.3 rad of press — tied to
      // the kick because that is the only signal that survives the frame the
      // shot was fired on.
      // (The trigger finger was driven here when the procedural hand rig was in
      // use. The authored NPC arm is a single skinned limb with no finger bones
      // to drive, so recoil and the kick curve carry the shot instead.)
    }

    // Flush world matrices so effects (which updates after us) samples the
    // exact on-screen muzzle position this frame.
    this.rig.updateMatrixWorld(true);
  }

  // ==========================================================================
  // Event handlers — flags and timers only
  // ==========================================================================
  _onEquip(p) {
    if (p && p.id && WEAPONS[p.id]) this._beginEquip(p.id);
  }

  _onFire(p) {
    if (!p || !p.byPlayer) return;
    const def = WEAPONS[p.weaponId];
    if (def && def.melee) {
      this._slash.active = true;
      this._slash.t = 0;
      this._slash.side = -this._slash.side; // alternate slash direction
      return;
    }
    const pose = POSES[p.weaponId];
    const ks = pose ? pose.kick : 0.6;
    if (ks <= 0) return;
    this._kick = Math.min(KICK_MAX, this._kick + 0.55 * ks);
    this._kickYawV = clamp(
      this._kickYawV + (Math.random() - 0.5) * 0.05 * ks,
      -0.06,
      0.06
    );
    this._kickRollV = clamp(
      this._kickRollV + (Math.random() - 0.5) * 0.06 * ks,
      -0.08,
      0.08
    );
    if (p.weaponId === 'awp') {
      this._bolt.active = true;
      this._bolt.t = -0.18; // short beat before the bolt is worked
    }
  }

  _onReloadStart(p) {
    this._reload.active = true;
    this._reload.t = 0;
    this._reload.dur = Math.max(0.5, (p && p.duration) || 2.5);
  }

  _onReloadEnd() {
    // Natural end lines up with the choreography; just make sure it stops.
    this._reload.active = false;
    const model = this._models[this._currentId];
    if (model && model.userData.mag) {
      model.userData.mag.position.y = model.userData.magBaseY;
    }
  }

  _onThrow() {
    this._throw.active = true;
    this._throw.t = 0;
    this._wind = Math.max(this._wind, 0.6); // release from a cocked pose
  }

  _onLand(p) {
    const speed = p && typeof p.speed === 'number' ? p.speed : 3;
    this._landK = Math.min(0.6, 0.14 + speed * 0.04);
  }

  // ==========================================================================
  // Weapon switching
  // ==========================================================================
  _beginEquip(id) {
    if (!this._models[id]) return;
    this._currentId = id;

    for (const key in this._models) {
      this._models[key].visible = key === id;
    }

    // Each wrapper carries its own arm clone, posed for that weapon's family,
    // so switching weapons needs no arm work here.

    // restore moving parts / payload of the incoming model
    const model = this._models[id];
    const ud = model.userData;
    if (ud.mag) ud.mag.position.y = ud.magBaseY;
    if (ud.slide) ud.slide.position.z = ud.slideBaseZ;
    if (ud.bolt) ud.bolt.position.z = ud.boltBaseZ;
    this._payloadHidden = false;
    if (ud.payload) {
      for (let i = 0; i < ud.payload.length; i++) ud.payload[i].visible = true;
    }

    // reset transient animation state (weapons cancels reloads silently on
    // switch — no reload:end event — so we must drop the anim here)
    const pose = POSES[id];
    this._equipDur = (pose && pose.equip) || EQUIP_DUR_DEFAULT;
    this._equipT = 0;
    this._reload.active = false;
    this._slash.active = false;
    this._throw.active = false;
    this._bolt.active = false;
    this._wind = 0;
    this._kick *= 0.25;
  }

  _setPayloadVisible(v) {
    const model = this._models[this._currentId];
    if (model && model.userData.payload) {
      const list = model.userData.payload;
      for (let i = 0; i < list.length; i++) list[i].visible = v;
    }
    this._payloadHidden = !v;
  }

  // ==========================================================================
  // Shared geometry / materials
  // ==========================================================================
  _initShared() {
    this.geo = {
      box: new THREE.BoxGeometry(1, 1, 1),
      cyl: new THREE.CylinderGeometry(0.5, 0.5, 1, 12),
      sph: new THREE.SphereGeometry(0.5, 14, 10),
      ring: new THREE.TorusGeometry(0.5, 0.11, 8, 18),
    };

    const MS = (o) => new THREE.MeshStandardMaterial(o);
    this.mats = {
      gunmetal: MS({ color: 0x3a3f45, metalness: 0.78, roughness: 0.38 }),
      gundark: MS({ color: 0x1e2124, metalness: 0.7, roughness: 0.45 }),
      polymer: MS({ color: 0x24272a, metalness: 0.12, roughness: 0.78 }),
      polymerLight: MS({ color: 0x33383d, metalness: 0.1, roughness: 0.85 }),
      wood: MS({ color: 0x7c4a24, metalness: 0.05, roughness: 0.55 }),
      woodDark: MS({ color: 0x59341a, metalness: 0.05, roughness: 0.6 }),
      // Note: keep metalness moderate — there is no environment map, and
      // fully metallic surfaces would render nearly black.
      chrome: MS({ color: 0xdfe3e8, metalness: 0.55, roughness: 0.25 }),
      steel: MS({ color: 0xc4cad0, metalness: 0.5, roughness: 0.3 }),
      awpGreen: MS({ color: 0x5d6b45, metalness: 0.25, roughness: 0.6 }),
      awpGreenDark: MS({ color: 0x49563a, metalness: 0.25, roughness: 0.62 }),
      lens: MS({ color: 0x0d1c2e, metalness: 0.9, roughness: 0.12 }),
      mag: MS({ color: 0x2c2c26, metalness: 0.6, roughness: 0.5 }),
      oliveHE: MS({ color: 0x3e4a2b, metalness: 0.35, roughness: 0.5 }),
      flashGray: MS({ color: 0x6b7178, metalness: 0.4, roughness: 0.4 }),
      smokeBody: MS({ color: 0x555e4c, metalness: 0.25, roughness: 0.6 }),
      band: MS({ color: 0x9aa1a7, metalness: 0.5, roughness: 0.5 }),
      blade: MS({ color: 0xd8dde2, metalness: 0.45, roughness: 0.28 }),
      edge: MS({ color: 0xf4f7f9, metalness: 0.35, roughness: 0.18 }),
      grip: MS({ color: 0x17191b, metalness: 0.1, roughness: 0.85 }),
    };
  }

  // ---- primitive helpers (every mesh: no shadows, never frustum-culled) ----
  _flags(m) {
    m.castShadow = false;
    m.receiveShadow = false;
    m.frustumCulled = false;
    return m;
  }

  _B(parent, mat, w, h, d, x, y, z, rx, ry, rz) {
    const m = new THREE.Mesh(this.geo.box, mat);
    m.scale.set(w, h, d);
    m.position.set(x || 0, y || 0, z || 0);
    if (rx || ry || rz) m.rotation.set(rx || 0, ry || 0, rz || 0);
    parent.add(this._flags(m));
    return m;
  }

  // Cylinder of radius r, length len, along axis 'y' | 'z' | 'x'.
  _C(parent, mat, r, len, x, y, z, axis) {
    const m = new THREE.Mesh(this.geo.cyl, mat);
    m.scale.set(r * 2, len, r * 2);
    if (axis === 'z') m.rotation.x = Math.PI / 2;
    else if (axis === 'x') m.rotation.z = Math.PI / 2;
    m.position.set(x || 0, y || 0, z || 0);
    parent.add(this._flags(m));
    return m;
  }

  _S(parent, mat, r, x, y, z, sx, sy, sz) {
    const m = new THREE.Mesh(this.geo.sph, mat);
    m.scale.set(r * 2 * (sx || 1), r * 2 * (sy || 1), r * 2 * (sz || 1));
    m.position.set(x || 0, y || 0, z || 0);
    parent.add(this._flags(m));
    return m;
  }

  // Torus ring of radius r, facing +Z by default.
  _R(parent, mat, r, x, y, z, rx, ry, rz) {
    const m = new THREE.Mesh(this.geo.ring, mat);
    const s = r * 2;
    m.scale.set(s, s, s);
    m.position.set(x || 0, y || 0, z || 0);
    if (rx || ry || rz) m.rotation.set(rx || 0, ry || 0, rz || 0);
    parent.add(this._flags(m));
    return m;
  }

  // ==========================================================================
  // Model construction — one distinct silhouette per weapon id
  // ==========================================================================
  _buildAll() {
    const builders = {
      knife: () => this._buildKnife(),
      glock: () => this._buildGlock(),
      usp: () => this._buildUSP(),
      deagle: () => this._buildDeagle(),
      mp5: () => this._buildMP5(),
      ak47: () => this._buildAK47(),
      m4a1: () => this._buildM4A1(),
      awp: () => this._buildAWP(),
      hegrenade: () => this._buildHE(),
      flashbang: () => this._buildFlashbang(),
      smokegrenade: () => this._buildSmoke(),
    };

    for (const id in WEAPONS) {
      const build = builders[id];
      if (!build) continue; // unknown future weapon: no model, muzzle falls back
      const group = build();
      group.name = 'vm-' + id;
      const pose = POSES[id] || { pos: [0.15, -0.14, -0.26], rot: [0, 0, 0] };
      group.position.set(
        pose.pos[0] - PIVOT_X,
        pose.pos[1] - PIVOT_Y,
        pose.pos[2] - PIVOT_Z
      );
      group.rotation.set(pose.rot[0], pose.rot[1], pose.rot[2]);
      group.userData.weaponSource = 'fallback';
      group.visible = false;
      this.pivot.add(group);
      this._models[id] = group;
    }
  }

  _muzzleAt(group, x, y, z) {
    const mz = new THREE.Object3D();
    mz.position.set(x, y, z);
    group.add(mz);
    group.userData.muzzle = mz;
  }

  // ==========================================================================
  // Procedural firearms (src/gfx/weapons).
  //
  // Every gun is real geometry at real scale — receiver, barrel, gas system,
  // handguard, optic, magazine, bolt, trigger — sharing the world's PBR
  // material library, so a rifle held in front of a wall is lit by the same
  // surfaces the wall is. They replace the authored GLBs for the seven
  // firearms; the knife and the grenades keep theirs.
  //
  // Their authoring convention is identical to the GLBs' (origin at the
  // shooting hand's grip anchor, bore down -Z, metres), which is why the
  // existing arm rig, poses and animation code need no changes: the moving
  // parts simply become real, so slide cycling and the AWP bolt now move
  // actual mechanism instead of a proxy box.
  // ==========================================================================
  _buildProceduralWeapons() {
    const revision=this._buildRevision=(this._buildRevision||0)+1;
    const library = this.game && this.game.materials;
    if (!library) {
      console.warn('[viewmodel] no material library — keeping primitive weapon models');
      return;
    }
    /**
     * Built one per frame, not seven in a row.
     *
     * Assembling a rifle — every part, then a merge and a weld per material
     * bucket — costs 150-300 ms, and doing all seven inside one call blocks the
     * main thread for nearly two seconds. Spread across frames the player sees
     * the menu the whole time and each gun simply replaces its primitive
     * placeholder as it lands. The starting pistols come first so the
     * placeholder is never on screen in a live round.
     */
    const t0 = typeof performance !== 'undefined' ? performance.now() : 0;
    const queue = [
      'usp', 'glock',
      ...PROCEDURAL_WEAPON_IDS.filter((id) => id !== 'usp' && id !== 'glock'),
    ].filter((id) => this._models[id]);

    let resolveReady,rejectReady;
    const ready=new Promise((resolve,reject)=>{resolveReady=resolve;rejectReady=reject;});
    let built = 0;
    const step = () => {
      if (this.game.disposed || revision!==this._buildRevision) { resolveReady(); return; }
      const id = queue.shift();
      if (id) {
        const object = weaponInstance(id, library, { viewmodel: true });
        if (object) {
          built++;
          this._applyProcedural(id, object, object.userData.model);
        } else { rejectReady(new Error("Failed to build native weapon: "+id)); return; }
      }
      if (queue.length) {
        requestAnimationFrame(step);
        return;
      }
      resolveReady();
      if (built && this.game.debug && t0) {
        const stats = weaponStats();
        console.info(
          `[viewmodel] ${built} procedural weapons · ${(stats.tris / 1000).toFixed(1)}k tris ` +
            `across ${stats.count} builds · ${(performance.now() - t0).toFixed(0)}ms`
        );
      }
    };

    // The first gun is built inline so a weapon is real by the first frame;
    // the rest arrive over the next few.
    step();
    return ready;
  }

  /**
   * Swap a built weapon into its persistent wrapper, exactly the way the GLB
   * path does — the wrapper node is what every animation and the equip
   * visibility toggle manipulate, so it is preserved.
   */
  _applyProcedural(id, object, model) {
    const group = this._models[id];
    for (let i = group.children.length - 1; i >= 0; i--) group.remove(group.children[i]);

    object.name = 'vm-proc-' + id;
    object.traverse(node=>{if(node.isMesh){node.castShadow=false;node.receiveShadow=false;}});
    group.add(object);
    group.userData.weaponSource = 'procedural';

    const pose = PROC_POSES[id] || GLB_POSES[id] || POSES[id];
    group.position.set(
      pose.pos[0] - PIVOT_X,
      pose.pos[1] - PIVOT_Y,
      pose.pos[2] - PIVOT_Z
    );
    group.rotation.set(pose.rot[0], pose.rot[1], pose.rot[2]);
    group.scale.setScalar(pose.scale ?? 1);

    // Muzzle marker, in wrapper space, at the real crown of the barrel — this
    // is where tracers and the flash spawn.
    //
    // `userData.muzzle` is a PLAIN ARRAY of three numbers, not a Vector3:
    // build.js keeps everything in weapon userData JSON-safe on purpose,
    // because Object3D.copy() round-trips userData and one built template is
    // cloned for this viewmodel and for every soldier carrying that gun.
    // `Vector3.copy()` reads .x/.y/.z, so calling it on that array wrote
    // `undefined` — not NaN, so nothing threw — into all three components, and
    // Object3D then composed a NaN matrix from them.
    //
    // MEASURED before this fix, on all seven procedural firearms:
    // getMuzzleWorldPos() returned (NaN, NaN, NaN), so combat emitted
    // 'fx:tracer' with from = (NaN, NaN, NaN) and effects spawned the flash,
    // the smoke wisp and the shell at NaN. A NaN vertex is discarded by the
    // rasterizer, so firing any firearm produced no tracer, no muzzle flash,
    // no smoke and no casing — nothing at all left the barrel. The knife and
    // the grenades were unaffected: they take the GLB path, which reads a real
    // `Muzzle` empty out of the file.
    const mz = new THREE.Object3D();
    mz.name = 'Muzzle';
    // Only a RECOGNISED shape counts. Leaving the marker at its default (0,0,0)
    // for an unknown shape would be finite and therefore pass every check while
    // spawning tracers out of the pistol grip instead of the barrel — a quieter
    // version of the same bug.
    const muzzleSpec = object.userData.muzzle;
    let muzzleOk = false;
    if (Array.isArray(muzzleSpec) && muzzleSpec.length >= 3) {
      mz.position.fromArray(muzzleSpec);
      muzzleOk = true;
    } else if (muzzleSpec && muzzleSpec.isVector3) {
      mz.position.copy(muzzleSpec);
      muzzleOk = true;
    }
    muzzleOk =
      muzzleOk &&
      Number.isFinite(mz.position.x) &&
      Number.isFinite(mz.position.y) &&
      Number.isFinite(mz.position.z);
    if (!muzzleOk) {
      console.warn(
        '[viewmodel] ' + id + ' has no usable muzzle node — tracers and the ' +
          'flash will fall back to the camera ray',
        muzzleSpec
      );
    }
    object.add(mz);

    // Bind the moving parts the animation layer drives. These are the real
    // mechanism now: the slide reciprocates, the magazine drops out of the
    // magwell and the bolt runs in the receiver.
    const ud = group.userData;
    const parts = object.userData.parts || {};
    void model;
    // A null muzzle is the documented "use the camera ray" signal; a NaN one is
    // an invisible tracer. Never store the latter.
    ud.muzzle = muzzleOk ? mz : null;
    ud.payload = null;
    ud.slide = parts.slide || null;
    ud.mag = parts.magazine || null;
    ud.bolt = parts.bolt || parts.charging || null;
    if (ud.slide) ud.slideBaseZ = ud.slide.position.z;
    if (ud.mag) ud.magBaseY = ud.mag.position.y;
    if (ud.bolt) ud.boltBaseZ = ud.bolt.position.z;
    ud.model = model;

    // Hand last, and it is the CHARACTER's hand.
    //
    // These seven briefly held a procedurally modelled pair of arms with
    // fingers solved onto the weapon's own grip nodes. It was rejected on
    // sight: a from-scratch hand next to the authored soldier reads as a
    // different game's asset, and two of them wrapped around the gun made it
    // worse, not better. The rule now is the same one the knife and the
    // grenades always followed — one arm, the operative's own, from
    // npc-arms-ct.glb, tinted by the player's chosen character palette.
    //
    // It is also much cheaper: the procedural pair was two limbs of jointed
    // fingers, and a viewmodel is drawn every frame.
    this._attachNPCArms(group, id);
  }

  /**
   * Seat the arm on this weapon's grip.
   *
   * `pose.pos` is deliberately an offset and not a target: it already has
   * `-R * S * NPC_ARM_FIST_CENTER` folded in (see NPC_ARM_POSES), so all this
   * has to do is write the three transforms. Anything that changes `rot` or
   * `scale` has to re-solve `pos` with it, or the middle of the fist walks off
   * the grip — that coupling is the whole reason the derivation is written down
   * beside the table.
   */
  _poseNPCArms(arms, id, weaponSource) {
    if (!arms) return; arms.position.set(0,0,0); arms.rotation.set(0,0,0); arms.scale.setScalar(1);
  }

  _attachNPCArms(group, id) {
    if(!group)return;
    group.userData.npcArms?.removeFromParent();
    const arms=createBeanViewArms(this.game.player?.team||'ct',id,group.userData.model);
    group.userData.npcArms=arms;group.add(arms);
  }

  _styleNPCArms(arms) { /* Bean uniforms are fixed by team at construction. */ }

  _applyNPCArms(gltf) {
    const source = gltf && (gltf.scene || (gltf.scenes && gltf.scenes[0]));
    if (!source) throw new Error('npc-arms-ct.glb has no scene');

    let hasSkinnedMesh = false;
    let grip = null;
    source.traverse((o) => {
      o.frustumCulled = false;
      if (o.isSkinnedMesh) hasSkinnedMesh = true;
      if (!grip && o.name === 'VM_Grip') grip = o;
      if (o.isMesh) {
        o.castShadow = false;
        o.receiveShadow = false;
      }
    });
    if (!hasSkinnedMesh) throw new Error('npc-arms-ct.glb has no SkinnedMesh');
    if (!grip) throw new Error('npc-arms-ct.glb has no VM_Grip origin');
    source.updateMatrixWorld(true);

    // VM_Grip is the actual clone root, not merely a marker. Reject exports
    // whose grip is transformed or whose visible skinned geometry has drifted
    // away from it; both conditions previously produced an invisible/offscreen
    // hand while still passing a name-only check.
    const identity = new THREE.Matrix4();
    const gripElements = grip.matrixWorld.elements;
    const identityElements = identity.elements;
    for (let i = 0; i < 16; i++) {
      if (Math.abs(gripElements[i] - identityElements[i]) > 1e-5) {
        throw new Error('npc-arms-ct.glb VM_Grip must be world-space identity');
      }
    }
    let gripHasSkinnedMesh = false;
    grip.traverse((o) => {
      if (o.isSkinnedMesh) gripHasSkinnedMesh = true;
    });
    if (!gripHasSkinnedMesh) {
      throw new Error('npc-arms-ct.glb SkinnedMesh must be parented under VM_Grip');
    }
    const armBounds = new THREE.Box3().setFromObject(grip);
    const armSize = armBounds.getSize(new THREE.Vector3());
    const gripPoint = new THREE.Vector3().setFromMatrixPosition(grip.matrixWorld);
    if (
      armBounds.isEmpty() ||
      armBounds.distanceToPoint(gripPoint) > 0.08 ||
      armSize.length() < 0.1 ||
      armSize.length() > 2.0
    ) {
      throw new Error('npc-arms-ct.glb hand bounds are not seated at VM_Grip');
    }
    this._npcArmsSource = grip;

    // Attach exactly one skeleton-safe clone to every persistent wrapper.
    // The wrappers are what equip/recoil/reload/throw animations manipulate,
    // so arm and weapon remain locked together for the whole animation.
    for (const id in this._models) {
      this._attachNPCArms(this._models[id], id);
    }
  }

  // ==========================================================================
  // GLB viewmodels — async load, swap group content in place on arrival.
  // Any failure (missing file, parse error, no loader) leaves the procedural
  // fallback model untouched for that weapon.
  // ==========================================================================
  _loadGLBModels() {
    const loader=new GLTFLoader();
    return Promise.all(Object.entries(LOCAL_MODELS).map(([id,url])=>new Promise((resolve,reject)=>{
      this._attachNPCArms(this._models[id],id);
      loader.load(url,gltf=>{
        try {this._applyGLB(id,gltf);resolve();} catch(error){reject(error);}
      },undefined,reject);
    })));
  }

  _applyGLB(id, gltf) {
    const group = this._models[id];
    const content = gltf && (gltf.scene || (gltf.scenes && gltf.scenes[0]));
    if (!group || !content) return;
    // The procedural build is spread over several frames, so a GLB request that
    // was queued while this wrapper still held its primitive placeholder can
    // land AFTER the real model has replaced it. Checking at queue time is not
    // enough — the guard has to be here, or the authored GLB silently overwrites
    // the procedural weapon a second later.
    if (group.userData.weaponSource === 'procedural') return;

    // Viewmodel render flags on everything; keep materials as authored.
    let muzzle = null;
    const filledMaterials = new Set();
    content.traverse((o) => {
      o.frustumCulled = false;
      if (o.isMesh) {
        o.castShadow = false;
        o.receiveShadow = false;
        // World sunlight can sit behind the camera-space viewmodel and turn
        // an otherwise readable authored gun into a black silhouette. A very
        // small albedo-matched emissive fill preserves the original material
        // colors while keeping the weapon legible in every part of the map.
        const materials = Array.isArray(o.material) ? o.material : [o.material];
        for (const material of materials) {
          if (
            !material ||
            filledMaterials.has(material) ||
            !material.emissive ||
            !material.color
          ) continue;
          filledMaterials.add(material);
          material.emissive.copy(material.color);
          material.emissiveIntensity = 0.45;
          material.needsUpdate = true;
        }
      }
      if (!muzzle && o.name === 'Muzzle') muzzle = o;
    });

    // Grenade payload is selected before the independent NPC arm is added.
    // The weapon body leaves on throw while the skinned arm stays visible.
    const def = WEAPONS[id];
    let payload = null;
    if (def && def.grenade) {
      payload = [];
      for (let i = 0; i < content.children.length; i++) {
        const c = content.children[i];
        if (c.name !== 'Muzzle') payload.push(c);
      }
    }

    // Swap content in place: the group node (what all animation code and the
    // equip visibility toggle manipulate) is preserved.
    const oldMuzzle = group.userData.muzzle || null;
    const arms = group.userData.npcArms || null;
    for (let i = group.children.length - 1; i >= 0; i--) {
      group.remove(group.children[i]);
    }
    content.name = 'vm-glb-' + id;
    content.scale.setScalar(GLB_POSES[id].scale);
    group.add(content);
    group.userData.weaponSource = 'glb';
    // Reuse the already-cloned skeleton so the async weapon swap cannot cause
    // a one-frame arm flicker or strand a second clone. Re-seat it at the real
    // GLB's identity grip origin after removing the fallback grip correction.
    if (arms) {
      this._poseNPCArms(arms, id, 'glb');
      group.add(arms);
    } else {
      this._attachNPCArms(group, id);
    }

    // Re-pose for the real-scale GLB (same camera-space convention as POSES).
    const pose = GLB_POSES[id];
    group.position.set(
      pose.pos[0] - PIVOT_X,
      pose.pos[1] - PIVOT_Y,
      pose.pos[2] - PIVOT_Z
    );
    group.rotation.set(pose.rot[0], pose.rot[1], pose.rot[2]);
    // The NPC arm uses effective camera-space meters, independent of each
    // GLB's authoring scale. Only the weapon content is scaled.
    group.scale.setScalar(1);

    // Rebind userData handles. GLBs have no separate moving parts, so the
    // slide/mag/bolt micro-animations become no-ops (whole-group reload /
    // kick / bolt choreography still applies).
    const ud = group.userData;
    ud.slide = null;
    ud.mag = null;
    ud.bolt = null;
    ud.payload = payload;
    if (muzzle) {
      ud.muzzle = muzzle;
    } else if (oldMuzzle) {
      // The procedural muzzle is already authored in wrapper-space meters.
      group.add(oldMuzzle);
      ud.muzzle = oldMuzzle;
      console.warn('[viewmodel] no Muzzle empty in ' + id + '.glb — using fallback offset');
    } else {
      ud.muzzle = null;
    }

    // If this weapon is on screen mid-throw, keep the payload hidden.
    if (payload && this._currentId === id && this._payloadHidden) {
      for (let i = 0; i < payload.length; i++) payload[i].visible = false;
    }
  }

  // ---- AK-47: wood furniture, slab receiver, banana mag ---------------------
  _buildAK47() {
    const g = new THREE.Group();
    const M = this.mats;
    // receiver + raised dust cover
    this._B(g, M.gundark, 0.03, 0.046, 0.15, 0, 0, 0.01);
    this._B(g, M.gunmetal, 0.028, 0.013, 0.128, 0, 0.029, 0.004);
    // rear sight block + charging handle nub (right side)
    this._B(g, M.gundark, 0.012, 0.01, 0.025, 0, 0.04, -0.045);
    this._B(g, M.gunmetal, 0.008, 0.008, 0.02, 0.019, 0.012, 0.03);
    // wood handguard: lower + upper gas-tube cover
    this._B(g, M.wood, 0.032, 0.026, 0.088, 0, -0.006, -0.118);
    this._B(g, M.wood, 0.028, 0.018, 0.08, 0, 0.024, -0.112);
    // barrel, gas block, front sight post, slanted muzzle brake
    this._C(g, M.gundark, 0.006, 0.11, 0, 0.008, -0.21, 'z');
    this._B(g, M.gundark, 0.012, 0.018, 0.014, 0, 0.02, -0.175);
    this._B(g, M.gundark, 0.006, 0.022, 0.007, 0, 0.032, -0.243);
    this._C(g, M.gunmetal, 0.0085, 0.024, 0, 0.008, -0.262, 'z');
    // curved magazine — two angled segments suggest the banana profile
    const mag = new THREE.Group();
    mag.position.set(0, -0.028, -0.018);
    this._B(mag, M.mag, 0.024, 0.056, 0.04, 0, -0.026, -0.004, 0.3, 0, 0);
    this._B(mag, M.mag, 0.022, 0.05, 0.036, 0, -0.07, -0.028, 0.62, 0, 0);
    g.add(mag);
    g.userData.mag = mag;
    g.userData.magBaseY = mag.position.y;
    // grip + wood stock + butt plate
    this._B(g, M.woodDark, 0.022, 0.05, 0.03, 0, -0.044, 0.052, -0.35, 0, 0);
    this._B(g, M.wood, 0.026, 0.05, 0.115, 0, -0.012, 0.14, -0.08, 0, 0);
    this._B(g, M.gundark, 0.028, 0.054, 0.008, 0, -0.016, 0.198);
    this._muzzleAt(g, 0, 0.008, -0.276);
    return g;
  }

  // ---- M4-A1: black, carry handle, railed handguard, vertical grip ----------
  _buildM4A1() {
    const g = new THREE.Group();
    const M = this.mats;
    // receiver + ejection port hint (right side)
    this._B(g, M.gundark, 0.03, 0.044, 0.13, 0, 0, 0.008);
    this._B(g, M.gunmetal, 0.002, 0.016, 0.028, 0.0155, 0.002, -0.012);
    // carry handle: two posts + top bar
    this._B(g, M.gundark, 0.008, 0.016, 0.01, 0, 0.032, 0.05);
    this._B(g, M.gundark, 0.008, 0.016, 0.01, 0, 0.032, -0.03);
    this._B(g, M.gundark, 0.012, 0.012, 0.108, 0, 0.044, 0.01);
    // handguard with top/bottom rail strips + vertical grip
    this._B(g, M.polymer, 0.034, 0.034, 0.098, 0, -0.002, -0.118);
    this._B(g, M.gundark, 0.01, 0.006, 0.098, 0, 0.018, -0.118);
    this._B(g, M.gundark, 0.01, 0.006, 0.098, 0, -0.022, -0.118);
    this._B(g, M.polymer, 0.018, 0.042, 0.02, 0, -0.045, -0.13);
    // front sight tower, barrel, birdcage flash hider
    this._B(g, M.gundark, 0.008, 0.024, 0.01, 0, 0.026, -0.175);
    this._C(g, M.gundark, 0.0055, 0.075, 0, 0.006, -0.205, 'z');
    this._C(g, M.gunmetal, 0.007, 0.02, 0, 0.006, -0.25, 'z');
    // magazine (straight, slightly raked)
    const mag = new THREE.Group();
    mag.position.set(0, -0.024, -0.028);
    this._B(mag, M.mag, 0.023, 0.062, 0.035, 0, -0.03, -0.006, 0.18, 0, 0);
    g.add(mag);
    g.userData.mag = mag;
    g.userData.magBaseY = mag.position.y;
    // grip, buffer tube, telescoping stock
    this._B(g, M.polymer, 0.022, 0.048, 0.028, 0, -0.042, 0.05, -0.3, 0, 0);
    this._C(g, M.gundark, 0.01, 0.06, 0, 0.008, 0.105, 'z');
    this._B(g, M.polymer, 0.03, 0.046, 0.05, 0, 0.002, 0.15);
    this._B(g, M.polymer, 0.032, 0.05, 0.008, 0, 0.0, 0.178);
    this._muzzleAt(g, 0, 0.006, -0.262);
    return g;
  }

  // ---- AWP: long green body, fat scope, bolt handle, bipod nubs -------------
  _buildAWP() {
    const g = new THREE.Group();
    const M = this.mats;
    // long green stock/body + cheek riser + butt
    this._B(g, M.awpGreen, 0.032, 0.05, 0.21, 0, 0, 0.03);
    this._B(g, M.awpGreenDark, 0.03, 0.026, 0.09, 0, 0.036, 0.095);
    this._B(g, M.awpGreenDark, 0.034, 0.068, 0.045, 0, -0.004, 0.175);
    this._B(g, M.gundark, 0.036, 0.07, 0.008, 0, -0.004, 0.2);
    // green forend + long barrel + brake
    this._B(g, M.awpGreen, 0.032, 0.04, 0.14, 0, -0.004, -0.135);
    this._C(g, M.gundark, 0.007, 0.17, 0, 0.014, -0.275, 'z');
    this._C(g, M.gunmetal, 0.009, 0.028, 0, 0.014, -0.365, 'z');
    // fat scope: tube, objective bell + lens, ocular + lens, turrets, mounts
    this._C(g, M.gundark, 0.014, 0.115, 0, 0.056, -0.005, 'z');
    this._C(g, M.gundark, 0.02, 0.035, 0, 0.056, -0.075, 'z');
    this._C(g, M.lens, 0.017, 0.004, 0, 0.056, -0.0935, 'z');
    this._C(g, M.gundark, 0.017, 0.028, 0, 0.056, 0.055, 'z');
    this._C(g, M.lens, 0.014, 0.003, 0, 0.056, 0.0705, 'z');
    this._C(g, M.gunmetal, 0.007, 0.012, 0, 0.076, -0.005, 'y');
    this._C(g, M.gunmetal, 0.007, 0.012, 0.02, 0.056, -0.005, 'x');
    this._B(g, M.gundark, 0.012, 0.014, 0.016, 0, 0.036, -0.032);
    this._B(g, M.gundark, 0.012, 0.014, 0.016, 0, 0.036, 0.024);
    // bolt handle (right side, angled down) — animated during bolt work
    const bolt = this._B(g, M.steel, 0.006, 0.006, 0.028, 0.021, 0.018, 0.04, 0, 0, -0.6);
    g.userData.bolt = bolt;
    g.userData.boltBaseZ = bolt.position.z;
    // short magazine, grip, bipod nubs under the forend
    this._B(g, M.gundark, 0.022, 0.034, 0.05, 0, -0.036, -0.02);
    this._B(g, M.awpGreenDark, 0.022, 0.05, 0.03, 0, -0.045, 0.075, -0.32, 0, 0);
    this._B(g, M.gundark, 0.006, 0.034, 0.006, 0.012, -0.038, -0.19, 0, 0, -0.25);
    this._B(g, M.gundark, 0.006, 0.034, 0.006, -0.012, -0.038, -0.19, 0, 0, 0.25);
    this._muzzleAt(g, 0, 0.014, -0.385);
    return g;
  }

  // ---- Night Hawk (Deagle): chrome slide over a black frame -----------------
  _buildDeagle() {
    const g = new THREE.Group();
    const M = this.mats;
    // chrome slide (animated) + gunmetal top rib + sights
    const slide = this._B(g, M.chrome, 0.028, 0.03, 0.148, 0, 0.014, -0.012);
    g.userData.slide = slide;
    g.userData.slideBaseZ = slide.position.z;
    this._B(g, M.gunmetal, 0.01, 0.006, 0.14, 0, 0.032, -0.012);
    this._B(g, M.gundark, 0.006, 0.007, 0.006, 0, 0.038, -0.078);
    this._B(g, M.gundark, 0.012, 0.007, 0.008, 0, 0.038, 0.055);
    // rear slide serration hint (slightly proud, darker)
    this._B(g, M.gunmetal, 0.0295, 0.024, 0.028, 0, 0.012, 0.048);
    // black frame + squared trigger guard + grip + hammer
    this._B(g, M.gundark, 0.026, 0.024, 0.11, 0, -0.012, -0.01);
    this._B(g, M.gundark, 0.006, 0.005, 0.032, 0, -0.032, -0.008);
    this._B(g, M.gundark, 0.006, 0.018, 0.005, 0, -0.024, -0.025);
    this._B(g, M.polymer, 0.026, 0.06, 0.034, 0, -0.05, 0.038, -0.3, 0, 0);
    this._B(g, M.gunmetal, 0.008, 0.012, 0.008, 0, 0.022, 0.065);
    // huge bore
    this._C(g, M.gundark, 0.0075, 0.006, 0, 0.018, -0.085, 'z');
    this._muzzleAt(g, 0, 0.018, -0.09);
    return g;
  }

  // ---- USP-S: slim black pistol with the signature suppressor ---------------
  _buildUSP() {
    const g = new THREE.Group();
    const M = this.mats;
    const slide = this._B(g, M.gundark, 0.026, 0.028, 0.132, 0, 0.012, -0.008);
    g.userData.slide = slide;
    g.userData.slideBaseZ = slide.position.z;
    // sights
    this._B(g, M.polymer, 0.005, 0.006, 0.005, 0, 0.03, -0.068);
    this._B(g, M.polymer, 0.012, 0.006, 0.007, 0, 0.03, 0.052);
    // polymer frame + accessory rail + rounded trigger guard
    this._B(g, M.polymer, 0.026, 0.022, 0.104, 0, -0.01, -0.012);
    this._B(g, M.polymer, 0.02, 0.008, 0.04, 0, -0.025, -0.045);
    this._B(g, M.polymer, 0.006, 0.005, 0.03, 0, -0.031, -0.004);
    this._B(g, M.polymer, 0.006, 0.016, 0.005, 0, -0.023, -0.021, 0.25, 0, 0);
    // grip
    this._B(g, M.polymer, 0.025, 0.058, 0.032, 0, -0.048, 0.036, -0.26, 0, 0);
    // SUPPRESSOR — the USP-S silhouette
    this._C(g, M.gunmetal, 0.008, 0.014, 0, 0.012, -0.078, 'z');
    this._C(g, M.gundark, 0.0115, 0.078, 0, 0.012, -0.117, 'z');
    this._muzzleAt(g, 0, 0.012, -0.158);
    return g;
  }

  // ---- G-18: boxy polymer, squared trigger guard, tall slide ----------------
  _buildGlock() {
    const g = new THREE.Group();
    const M = this.mats;
    const slide = this._B(g, M.polymer, 0.028, 0.03, 0.122, 0, 0.013, -0.004);
    g.userData.slide = slide;
    g.userData.slideBaseZ = slide.position.z;
    // rear serration hint + sights
    this._B(g, M.grip, 0.0285, 0.022, 0.024, 0, 0.012, 0.045);
    this._B(g, M.grip, 0.005, 0.006, 0.005, 0, 0.031, -0.06);
    this._B(g, M.grip, 0.012, 0.006, 0.007, 0, 0.031, 0.05);
    // lighter polymer frame + squared trigger guard
    this._B(g, M.polymerLight, 0.027, 0.022, 0.1, 0, -0.009, -0.008);
    this._B(g, M.polymerLight, 0.007, 0.005, 0.034, 0, -0.03, -0.008);
    this._B(g, M.polymerLight, 0.007, 0.016, 0.005, 0, -0.022, -0.026);
    // upright boxy grip with backstrap hump
    this._B(g, M.polymerLight, 0.027, 0.058, 0.032, 0, -0.044, 0.036, -0.2, 0, 0);
    this._B(g, M.polymerLight, 0.024, 0.02, 0.01, 0, -0.022, 0.055);
    this._muzzleAt(g, 0, 0.013, -0.068);
    return g;
  }

  // ---- MP-5: stubby SMG, tube receiver, curved mag, front sight ring --------
  _buildMP5() {
    const g = new THREE.Group();
    const M = this.mats;
    // tube upper receiver over a boxy trigger group
    this._C(g, M.gundark, 0.015, 0.135, 0, 0.008, -0.045, 'z');
    this._B(g, M.polymer, 0.028, 0.03, 0.115, 0, -0.014, -0.02);
    // chunky polymer handguard
    this._B(g, M.polymer, 0.033, 0.034, 0.068, 0, -0.008, -0.115);
    // front sight ring + post, rear sight drum
    this._R(g, M.gundark, 0.011, 0, 0.034, -0.15);
    this._B(g, M.gundark, 0.004, 0.014, 0.004, 0, 0.032, -0.15);
    this._C(g, M.gundark, 0.008, 0.012, 0, 0.032, 0.01, 'x');
    // short barrel
    this._C(g, M.gundark, 0.005, 0.045, 0, 0.008, -0.172, 'z');
    // curved magazine (two raked segments)
    const mag = new THREE.Group();
    mag.position.set(0, -0.03, -0.055);
    this._B(mag, M.mag, 0.02, 0.052, 0.032, 0, -0.024, -0.006, 0.35, 0, 0);
    this._B(mag, M.mag, 0.018, 0.048, 0.028, 0, -0.064, -0.032, 0.7, 0, 0);
    g.add(mag);
    g.userData.mag = mag;
    g.userData.magBaseY = mag.position.y;
    // grip + slim stock rails + butt pad
    this._B(g, M.polymer, 0.022, 0.046, 0.028, 0, -0.046, 0.02, -0.3, 0, 0);
    this._B(g, M.gundark, 0.006, 0.008, 0.09, 0.011, 0.006, 0.075);
    this._B(g, M.gundark, 0.006, 0.008, 0.09, -0.011, 0.006, 0.075);
    this._B(g, M.polymer, 0.03, 0.044, 0.012, 0, 0.002, 0.122);
    this._muzzleAt(g, 0, 0.008, -0.198);
    return g;
  }

  // ---- Knife: blade with bright edge bevel, guard, wrapped grip -------------
  _buildKnife() {
    const g = new THREE.Group();
    const M = this.mats;
    // grip + pommel + guard
    this._B(g, M.grip, 0.02, 0.028, 0.088, 0, 0, 0.05);
    this._B(g, M.gunmetal, 0.022, 0.03, 0.012, 0, 0, 0.096);
    this._B(g, M.gunmetal, 0.03, 0.008, 0.012, 0, 0, 0.002);
    // blade: thin slab, bright edge bevel strip, tapered clip point
    this._B(g, M.blade, 0.006, 0.032, 0.15, 0, 0.001, -0.072);
    this._B(g, M.edge, 0.0026, 0.009, 0.146, 0, -0.0155, -0.07);
    this._B(g, M.blade, 0.0055, 0.024, 0.055, 0, 0.003, -0.162, -0.24, 0, 0);
    this._muzzleAt(g, 0, 0, -0.19);
    return g;
  }

  // ---- HE grenade: olive sphere, fuze, safety lever + pull ring -------------
  _buildHE() {
    const g = new THREE.Group();
    const M = this.mats;
    const payload = [];
    payload.push(this._S(g, M.oliveHE, 0.033, 0, 0, 0, 1, 1.12, 1));
    payload.push(this._C(g, M.gunmetal, 0.009, 0.016, 0, 0.043, 0, 'y'));
    payload.push(this._C(g, M.gunmetal, 0.006, 0.008, 0, 0.054, 0, 'y'));
    payload.push(this._B(g, M.steel, 0.01, 0.0035, 0.045, 0.006, 0.038, 0.016, -0.55, 0, 0.1));
    payload.push(this._R(g, M.steel, 0.008, 0.017, 0.045, 0.01, 1.2, 0, 0));
    g.userData.payload = payload;
    this._muzzleAt(g, 0, 0.01, -0.04);
    return g;
  }

  // ---- Flashbang: gray steel cylinder, vent band, lever ---------------------
  _buildFlashbang() {
    const g = new THREE.Group();
    const M = this.mats;
    const payload = [];
    payload.push(this._C(g, M.flashGray, 0.02, 0.075, 0, 0.002, 0, 'y'));
    payload.push(this._C(g, M.gundark, 0.0205, 0.01, 0, -0.012, 0, 'y')); // vent band
    payload.push(this._C(g, M.gunmetal, 0.014, 0.012, 0, 0.045, 0, 'y'));
    payload.push(this._C(g, M.gunmetal, 0.006, 0.01, 0, 0.056, 0, 'y'));
    payload.push(this._B(g, M.steel, 0.009, 0.0035, 0.042, 0.005, 0.042, 0.014, -0.55, 0, 0.1));
    payload.push(this._R(g, M.steel, 0.008, 0.016, 0.048, 0.008, 1.2, 0, 0));
    g.userData.payload = payload;
    this._muzzleAt(g, 0, 0.01, -0.04);
    return g;
  }

  // ---- Smoke: taller olive-drab canister with a pale marking band -----------
  _buildSmoke() {
    const g = new THREE.Group();
    const M = this.mats;
    const payload = [];
    payload.push(this._C(g, M.smokeBody, 0.022, 0.088, 0, 0, 0, 'y'));
    payload.push(this._C(g, M.band, 0.0225, 0.012, 0, 0.028, 0, 'y'));
    payload.push(this._C(g, M.gunmetal, 0.015, 0.012, 0, 0.05, 0, 'y'));
    payload.push(this._C(g, M.gunmetal, 0.006, 0.01, 0, 0.061, 0, 'y'));
    payload.push(this._B(g, M.steel, 0.009, 0.0035, 0.044, 0.005, 0.048, 0.015, -0.55, 0, 0.1));
    payload.push(this._R(g, M.steel, 0.008, 0.016, 0.054, 0.008, 1.2, 0, 0));
    g.userData.payload = payload;
    this._muzzleAt(g, 0, 0.01, -0.04);
    return g;
  }
}
